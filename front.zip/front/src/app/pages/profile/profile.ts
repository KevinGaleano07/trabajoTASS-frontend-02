import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { AuthServiceTs } from '../../core/services/auth.service';
import { SweetAlertService } from '../../core/services/sweet-alert.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

const passwordMatchValidator: ValidatorFn = (
  control: AbstractControl,
): ValidationErrors | null => {

  const newPassword = control.get('newPassword')?.value;
  const confirmPassword = control.get('confirmPassword')?.value;

  if (!newPassword || !confirmPassword) {
    return null
  }

  return newPassword === confirmPassword ? null : { passwordMismatch: true };

};


@Component({
  selector: 'app-profile',
  imports: [MatIconModule, ReactiveFormsModule],
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile {

  private readonly fb = inject(FormBuilder);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly authService = inject(AuthServiceTs);
  private readonly sweetAlert = inject(SweetAlertService);
  private readonly router = inject(Router);

  isPasswordModalOpen = false;
  isSubmitting = false;
  currentPasswordVisible = false;
  newPasswordVisible = false;
  confirmPasswordVisible = false;

  currentUser = this.authService.getCurrentUser();
  initials = this.getInitials();
  isEditingProfile = false;
  isProfileSubmitting = false;

  profileForm = this.fb.nonNullable.group({
    nombres: ['', [Validators.required, Validators.minLength(2)]],
    correo: ['', [Validators.required, Validators.email]],
    telefono: ['', [Validators.required, Validators.pattern(/^\d{10,}$/)]],
  });

  passwordForm = this.fb.nonNullable.group(
    {
      currentPassword: ['', Validators.required],

      newPassword: ['', [
        Validators.required,
        Validators.minLength(9),
        Validators.pattern(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_]).{9,}$/
        ),
      ],
      ],

      confirmPassword: ['',
        Validators.required,
      ],
    },
    {
      validators: passwordMatchValidator
    }
  );

  openPasswordModal(): void {
    this.passwordForm.reset();
    this.isSubmitting = false;
    this.isPasswordModalOpen = true;
  }

  closePasswordModal(): void {
    this.passwordForm.reset();
    this.isSubmitting = false;
    this.currentPasswordVisible = false;
    this.newPasswordVisible = false;
    this.confirmPasswordVisible = false;
    this.isPasswordModalOpen = false;
  }

  private getInitials(): string {
    const firstName = this.currentUser?.nombres.trim().charAt(0) ?? '';
    const lastName = this.currentUser?.apellidos.trim().charAt(0) ?? '';
    return `${firstName}${lastName}`.toLocaleUpperCase() || 'U';
  }

  startEditingProfile(): void {
    if (!this.currentUser) return;

    this.profileForm.reset({
      nombres: this.currentUser.nombres,
      correo: this.currentUser.correo,
      telefono: this.currentUser.telefono,
    });
    this.isEditingProfile = true;
  }

  cancelProfileEdit(): void {
    this.profileForm.reset();
    this.isEditingProfile = false;
    this.isProfileSubmitting = false;
  }

  saveProfile(): void {
    if (this.isProfileSubmitting) return;

    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }

    this.isProfileSubmitting = true;
    this.cdr.detectChanges();
    this.authService.updateProfile(this.profileForm.getRawValue()).subscribe({
      next: (response) => {
        this.authService.saveToken(response.data.token);
        this.currentUser = response.data.user;
        this.initials = this.getInitials();
        this.isProfileSubmitting = false;
        this.isEditingProfile = false;
        this.cdr.detectChanges();
        this.sweetAlert.success(response.message);
      },
      error: (error: HttpErrorResponse) => {
        this.isProfileSubmitting = false;
        const fieldErrors = error.error?.details?.fieldErrors as Record<string, string> | undefined;

        if (fieldErrors) {
          for (const [field, message] of Object.entries(fieldErrors)) {
            const control = this.profileForm.get(field);
            if (control) {
              control.setErrors({ ...control.errors, backend: message });
              control.markAsTouched();
            }
          }
          this.cdr.detectChanges();
          return;
        }

        this.cdr.detectChanges();
        this.sweetAlert.error(error.error?.message ?? 'No se pudo actualizar el perfil.');
      },
    });
  }

  changePassword(): void {

    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();
      return;
    }

    const {
      currentPassword,
      newPassword,
    } = this.passwordForm.getRawValue();

    this.isSubmitting = true;

    this.authService.changePassword({
      currentPassword,
      newPassword,
    }).subscribe({

      next: (response) => {

        this.isSubmitting = false;
        this.closePasswordModal();
        this.sweetAlert.success(response.message).then(() => {

          this.authService.logout();

          this.router.navigate(['/login'])
        });

      },

      error: (error) => {

        this.isSubmitting = false;
        this.sweetAlert.error(error?.error?.message ?? 'No se pudo cambiar la contraseña.');

      }
    });
  }
}
