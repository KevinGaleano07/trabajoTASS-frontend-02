import { Component, DestroyRef, EventEmitter, Input, Output, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AuthServiceTs } from '../../../core/services/auth.service';

@Component({
  selector: 'app-header',
  imports: [MatIconModule],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {

  private readonly authService = inject(AuthServiceTs);
  private readonly destroyRef = inject(DestroyRef);

  @Input() showProfile = false;

  @Output() notificationClick = new EventEmitter<void>();

  nombreUsuario = '';
  inicialesUsuario = 'U';

  constructor() {
    this.authService.currentUser$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((user) => {
        this.nombreUsuario = `${user?.nombres ?? ''} ${user?.apellidos ?? ''}`.trim();
        const firstName = user?.nombres.trim().charAt(0) ?? '';
        const lastName = user?.apellidos.trim().charAt(0) ?? '';
        this.inicialesUsuario = `${firstName}${lastName}`.toLocaleUpperCase() || 'U';
      });
  }

  onNotificationClick(): void {
    this.notificationClick.emit();
  }
}
