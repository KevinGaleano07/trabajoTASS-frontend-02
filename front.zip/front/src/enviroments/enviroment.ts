export const environment = {
  production: false,
  apiUrl: '/api/auth',
  apico: '/api',
  apiconflicts: '/api/conflicts'

};
