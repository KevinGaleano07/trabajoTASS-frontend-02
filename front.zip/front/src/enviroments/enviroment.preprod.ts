export const environment = {
  production: true,
  apiUrl: '/api/auth',
  apico: '/api',
  apiconflicts: '/api/conflicts'

};
