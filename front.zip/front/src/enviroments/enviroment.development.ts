export const environment = {
  production: false,
  // apiUrl: 'http://localhost:3000/api/auth'
  apiUrl: 'http://3.14.133.213:3000/api/auth',
  apico: 'http://3.14.133.213:3000/api',
  apiconflicts: 'http://3.14.133.213:3000/api/conflicts'

};
