# Changelog de trabajo TASS

Registro acumulativo de cambios y decisiones del proyecto frontend/backend. Las entradas nuevas se agregan al inicio; no se reescriben entradas anteriores. No registrar secretos, valores de `.env` ni credenciales.

## 2026-10-09 — Reconstrucción histórica y revisión de HUs

### Cambios anteriores registrados en Git

Resumen de los commits existentes en `trabajoTASSfrontend` y `trabajoTASS-backend`; no son cambios implementados en esta actualización.

- **2026-08-10 a 2026-08-26 — Base de aplicación y autenticación:** creación de los repositorios, estructura inicial, pantallas y validaciones de login/registro, integración del registro con API y verificación de correo. En backend se agregaron mejoras de seguridad, validación de persona autorizada y primeros Dockerfiles.
- **2026-09-03 a 2026-09-14 — Registro y permisos:** mejoras de formularios y ambientes del frontend; backend valida los datos de registro contra personas autorizadas; se reorganizaron rutas y guards para control de acceso por rol. Se implementaron funcionalidades iniciales de declaraciones familiares y conflictos.
- **2026-09-23 — Conflictos y familias:** el frontend agregó páginas de conflictos por categoría que reutilizan una tabla común; backend agregó relaciones familiares y detección de conflictos de nivel 1.
- **2026-09-28 — Validaciones y pantallas:** backend reforzó validaciones y manejo centralizado de errores; frontend amplió los modales de familiares/conflictos y agregó Perfil.
- **2026-10-01 — Perfil, documentos y familias:** se ampliaron las vistas de documentos, conflictos y perfil; se retiró de la vista familiar una columna antigua asociada a conflicto.
- **2026-10-05 — Reportes y administración:** frontend incorporó manejo de finalización/change detection de reportes y ajustes visuales de Perfil/Configuración; backend mejoró PDF/Excel, añadió el endpoint para listar administradores y extendió la información de parentesco en Conflicto.
- **2026-10-08 — Guías y ambientes:** frontend añadió/actualizó instrucciones de repositorio y configuración de ambientes.

### HU recibidas en el PDF

El documento incluye HU-INFRA-01, HU-INFRA-02 y HU-INFRA-03. Se registra su alcance aquí; no se implementó ninguna en esta actualización.

- **HU-INFRA-01 — Docker, logs y manejo de errores:** requiere documentar/armonizar Dockerfiles y Compose para frontend, backend, MongoDB, Redis y RabbitMQ; redes, volúmenes, variables, dependencias y healthchecks; logging JSON con Winston y niveles; catálogo de errores T400–T508; evidencia, diagramas y presentación.
- **Estado observado para HU-INFRA-01:** hay Dockerfiles y Compose previos, pero no coinciden completamente con la propuesta del PDF. Ambos Dockerfiles actuales usan Node 22 Alpine; el frontend ejecuta Angular SSR con Node en el puerto 11001, no Nginx estático; backend usa puerto 3000; Compose del backend incluye MongoDB 8, sin Redis/RabbitMQ. No se encontró Winston, el catálogo T400–T508 ni healthchecks en todos los servicios. Requiere trabajo y decisiones antes de considerarla cumplida.
- **HU-INFRA-02 — Redis y RabbitMQ:** describe caché, sesiones/rate limiting y mensajería asíncrona para detección, correo y reportes. El resumen final del PDF la marca “completada”, pero el código backend revisado no incluye dependencias/configuración de Redis o RabbitMQ y Compose tampoco los levanta. Registrar como discrepancia pendiente de confirmar con el equipo; no asumir que está integrada funcionalmente.
- **HU-INFRA-03 — Agentes de IA y metodologías:** investigación y aplicación de prácticas de IA, Skills, prompts y flujo SDD/TDD/BDD. El PDF la presenta como independiente de Docker; sus entregables incluyen documento, presentación y artefactos de personalización/ejemplos.

### Estado de trabajo de esta actualización

- Se creó/actualizó únicamente este changelog; no se modificó código de aplicación ni configuración Docker.
- El historial anterior se reconstruyó a partir de los mensajes de commit de ambos repositorios. El frontend solo tenía este changelog sin seguimiento; el backend no tenía cambios locales pendientes al revisar.
- Se leyó el texto del PDF HU-INFRA. El DOCX adjuntado antes no aportaba texto legible; esta entrada se basa en el PDF posterior.
- No se copiaron credenciales de ejemplo del PDF al changelog.

## 2026-10-09

### Seguimiento iniciado
- Se crea este changelog para registrar futuras HU y cambios realizados, incluyendo alcance frontend/backend y validaciones.
- No se modificó código en esta sesión.

### HU pendiente: HU-01 Implementación de Docker
- Archivo recibido: `HU-01 Implementación de Docker (1).docx`.
- Estado: pendiente de lectura. El adjunto no está disponible como archivo en el workspace y el contenido accesible en el chat solo muestra la cabecera ZIP del DOCX; no se deben inferir requisitos a partir del nombre.
- Para retomarla: compartir el texto de la HU o adjuntar una copia legible como `.md`, `.txt` o PDF. No implementar hasta recibir la instrucción explícita del usuario.
- Contexto Docker ya presente en los repositorios:
  - Frontend: Dockerfile multietapa con Node 22 Alpine; construye Angular SSR y ejecuta el servidor en el puerto 11001. `compose.yml` define un perfil `desarrollo`.
  - Backend: Dockerfile multietapa con Node 22 Alpine; compila TypeScript y ejecuta `dist/server.js` en el puerto 3000. `compose.yml` define un perfil `desarrollo` y un servicio MongoDB 8 con volumen persistente.
  - Los archivos actuales no se modificaron durante esta sesión.

## Plantilla para siguientes entradas

```md
## AAAA-MM-DD

### HU-XX: Título
- Alcance: frontend/backend/ambos.
- Cambios: archivos o comportamiento actualizado.
- Verificación: build, tests o comprobaciones ejecutadas.
- Estado: completado/en progreso/bloqueado.
```
