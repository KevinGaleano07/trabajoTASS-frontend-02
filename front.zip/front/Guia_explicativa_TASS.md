# Guía explicativa TASS — Puntos clave desmenuzados

**Sistema de detección de conflictos de interés**  
Guía de estudio desde cero basada en los archivos incluidos en `trabajoTASS-backend.zip` y `trabajoTASSfrontend.zip`.  
**Fecha de revisión:** 16 de octubre de 2026.

> **Cómo leer esta guía.** Cada apartado explica qué es el concepto, para qué sirve, cómo funciona, cómo aparece en TASS, un ejemplo, errores frecuentes, sus conexiones y una pregunta de autoevaluación. Las rutas son relativas a la raíz del repositorio indicado. Cuando una explicación depende de una descripción de Copilot y no del código verificable, se marca como tal. La configuración real puede cambiar entre commits.

## Índice

1. [Creación de usuario mediante AuthorizedPerson](#1-creación-de-usuario-mediante-authorizedperson)
2. [Envío de correos para crear cuentas](#2-envío-de-correos-para-crear-cuentas)
3. [Token frente a Bearer](#3-token-frente-a-bearer)
4. [Flujo del botón Detectar conflictos](#4-flujo-del-botón-detectar-conflictos)
5. [Cambiar un conflicto de resuelto a pendiente](#5-cambiar-un-conflicto-de-resuelto-a-pendiente)
6. [Descarga de PDF y Excel con datos actuales](#6-descarga-de-pdf-y-excel-con-datos-actuales)
7. [Detección de conflictos nuevos](#7-detección-de-conflictos-nuevos)
8. [Reconocimiento de una relación familiar nueva](#8-reconocimiento-de-una-relación-familiar-nueva)
9. [Mantener fija la sección seleccionada](#9-mantener-fija-la-sección-seleccionada)
10. [Una tabla y vistas distintas según el rol](#10-una-tabla-y-vistas-distintas-según-el-rol)
11. [Tasa de resolución y tiempo promedio](#11-tasa-de-resolución-y-tiempo-promedio)
12. [Qué contiene cada columna del Excel](#12-qué-contiene-cada-columna-del-excel)
13. [Configuración local, pruebas y producción](#13-configuración-local-pruebas-y-producción)
14. [Winston frente a console.log](#14-winston-frente-a-consolelog)
15. [Cada funcionalidad de logger.ts](#15-cada-funcionalidad-de-loggerts)
16. [Por qué funciona logError(...) sin function al inicio](#16-por-qué-funciona-logerror-sin-function-al-inicio)
17. [Archivo health.routes.ts de principio a fin](#17-archivo-healthroutests-de-principio-a-fin)
18. [Archivos Docker y, en especial, Compose](#18-archivos-docker-y-en-especial-compose)
19. [Por qué no publicar Mongo en el host](#19-por-qué-no-publicar-mongo-en-el-host)
20. [Probar un healthcheck con un contenedor temporal](#20-probar-un-healthcheck-con-un-contenedor-temporal)
21. [Winston: propósito e importancia](#21-winston-propósito-e-importancia)
22. [Qué significa acceder por DNS interno de Compose](#22-qué-significa-acceder-por-dns-interno-de-compose)
23. [Separar preproducción y pruebas en Docker](#23-separar-preproducción-y-pruebas-en-docker)
24. [Vite, Alpine y SSR](#24-vite-alpine-y-ssr)
25. [Por qué Node construye y Nginx sirve el frontend SPA](#25-por-qué-node-construye-y-nginx-sirve-el-frontend-spa)
26. [Healthcheck: definición, límites y estados](#26-healthcheck-definición-límites-y-estados)
27. [Cómo Nginx encuentra el backend](#27-cómo-nginx-encuentra-el-backend)
28. [Catálogo de errores errorCatalog.ts](#28-catálogo-de-errores-errorcatalogts)
29. [Qué hace Nginx en el frontend](#29-qué-hace-nginx-en-el-frontend)
30. [Redis, RabbitMQ y redis.ts](#30-redis-rabbitmq-y-redists)
31. [cacheService.ts](#31-cacheservicets)
32. [Interpretar el mensaje de Copilot sobre Redis y Compose](#32-interpretar-el-mensaje-de-copilot-sobre-redis-y-compose)
33. [rabbitmq.ts](#33-rabbitmqts)
34. [vhost, broker, consumer y colas](#34-vhost-broker-consumer-y-colas)
35. [definitions.json y RABBITMQ_URL](#35-definitionsjson-y-rabbitmq_url)
36. [Reportes con RabbitMQ, SSE, auditoría, push, smoke test, DLQ y SMTP](#36-reportes-con-rabbitmq-sse-auditoría-push-smoke-test-dlq-y-smtp)
37. [Glosario consolidado](#glosario-consolidado)
38. [Mapa mental de TASS](#mapa-mental-de-tass)

---

## 1. Creación de usuario mediante AuthorizedPerson

### a) Qué es
`AuthorizedPerson` es un registro previo que indica qué persona, identificada por tipo y número de documento y asociada a un cargo, está autorizada para registrarse en TASS. **No es la cuenta de acceso**: es la autorización que el proceso de registro consulta antes de crearla.

### b) Para qué sirve
Evita que cualquier persona que conozca la URL de registro pueda crear una cuenta libremente. El flujo exige que los datos del solicitante coincidan con una persona autorizada y activa. Esto separa la decisión administrativa de autorizar a alguien de la creación de sus credenciales.

### c) Cómo funciona
En `backend/src/models/AuthorizedPerson.ts`, Mongoose define los campos `tipoDocumento`, `numeroDocumento`, `cargo` y `estado`. Los tipos de documento permitidos son `CC`, `CE`, `NIT` y `PASAPORTE`; el estado es `ACTIVO` o `INACTIVO`, y por defecto se establece `ACTIVO`. `timestamps: true` hace que Mongoose mantenga fechas de creación y actualización.

La ruta `POST /api/authorized-person` se conecta con `createAuthorizedPerson` en `backend/src/routes/authorized-person.routes.ts` y `backend/src/controllers/authorized-person.controller.ts`. El controlador comprueba que existan los campos obligatorios, normaliza el documento, valida su formato, comprueba que no exista otro registro con ese número y finalmente guarda el documento. Para pasaporte exige al menos una letra y permite letras y números; para los demás tipos exige dígitos. Si todo sale bien devuelve HTTP 201.

Luego, cuando alguien se registra, `backend/src/controllers/auth.controller.ts` busca un registro `AuthorizedPerson` con el mismo tipo y número de documento y con `estado: 'ACTIVO'`. También compara el cargo autorizado con el cargo enviado en el formulario, ignorando diferencias de mayúsculas y espacios exteriores. Solo entonces crea el usuario en `UserModel`.

### d) Cómo se usa en TASS
El recorrido real es: administrador o proceso autorizado registra la persona autorizada → MongoDB guarda el documento `AuthorizedPerson` → la persona abre el formulario de registro → `register()` valida el formulario → el backend consulta `AuthorizedPerson` → compara cargo → guarda el usuario en estado `PENDIENTE` → encola el correo de verificación. La autorización previa y la cuenta son dos documentos distintos.

### e) Ejemplo aplicado a TASS
Se registra una persona autorizada con documento `CC`, número `1234567890`, cargo `Analista` y estado `ACTIVO`. Cuando el usuario envía el formulario con esos mismos datos, el backend puede continuar. Si escribe `Coordinador`, la comparación de cargo falla y la cuenta no se crea. Si la persona autorizada está `INACTIVO`, también se rechaza el registro.

### f) Errores comunes
No confundas `AuthorizedPerson` con `User`: el primero autoriza y el segundo contiene la cuenta y su contraseña cifrada. Crear una persona autorizada no crea automáticamente un usuario ni envía correo. En el código actual, la búsqueda previa de duplicado en el controlador usa solo `numeroDocumento`, aunque el esquema también tiene un índice `unique`; por tanto, el comportamiento efectivo puede ser más restrictivo que la combinación tipo-documento. El endpoint mostrado no incorpora middleware de rol en ese archivo; no debe asumirse que la autorización de acceso al endpoint está garantizada sin revisar el montaje completo de rutas y controles.

### g) Conexiones
Se relaciona con el modelo `User`, el registro de `auth.controller.ts`, la validación de `registration.validator.ts`, el servicio de correo y el estado `PENDIENTE` de la cuenta. También conecta con el catálogo de errores porque datos repetidos o inválidos deben traducirse a respuestas comprensibles.

**Autoevaluación:** ¿Puedes explicar por qué una persona puede estar autorizada en `AuthorizedPerson` sin tener todavía usuario, contraseña ni sesión?

---

## 2. Envío de correos para crear cuentas

### a) Qué es
Es el proceso que envía un enlace de verificación al correo indicado durante el registro para confirmar que el solicitante controla esa dirección antes de activar la cuenta.

### b) Para qué sirve
Reduce registros con correos mal escritos o ajenos, y separa “cuenta creada” de “cuenta activada”. Una cuenta puede existir en MongoDB y seguir en estado `PENDIENTE`; no debería tratarse como activa solo porque el formulario terminó correctamente.

### c) Cómo funciona
En `backend/src/controllers/auth.controller.ts`, `register()` valida la información, comprueba duplicados, verifica la persona autorizada, cifra la contraseña con `bcrypt.hash(..., 10)`, crea el usuario con `estado: 'PENDIENTE'` y luego llama a `enqueueVerificationEmail(user._id.toString())`. En la implementación con RabbitMQ, esa función publica un mensaje en `tass.email.notification`. Un consumidor en `backend/src/services/messageConsumer.ts` recibe el identificador de usuario, recupera el usuario de MongoDB, genera un token de verificación y llama a `sendVerificationEmail` en `backend/src/services/email.service.ts`.

El servicio de correo prepara el mensaje con Nodemailer y la plantilla `backend/src/templates/emails/verify-email.ejs`. La configuración SMTP —servidor, puerto, usuario y contraseña— se obtiene de variables de entorno. SMTP es el protocolo que permite entregar el correo al servidor de correo. El enlace lleva un token de tipo `verify-email`; al abrirlo, `verifyEmail()` valida el token y cambia el estado del usuario a `ACTIVO`, después redirige al frontend a `/login?verified=true`.

### d) Cómo se usa en TASS
La respuesta de registro puede llegar antes de que el consumidor termine de enviar el correo porque el registro encola una tarea. Esto evita que el tiempo de respuesta dependa directamente de la latencia SMTP, pero significa que HTTP 201 indica que se creó la cuenta y se aceptó la solicitud de envío, no necesariamente que el mensaje ya llegó a la bandeja de entrada.

### e) Ejemplo aplicado a TASS
Una persona se registra con su correo corporativo. El backend guarda el usuario como `PENDIENTE`, publica el trabajo de correo y responde “La cuenta está pendiente de activación”. El consumidor construye el enlace. La persona pulsa el enlace; el backend verifica que el token sea del tipo correcto y activa la cuenta. Si el correo falla, se debe investigar el log y la cola; no es correcto asumir que el correo llegó solo por ver el mensaje de éxito del frontend.

### f) Errores comunes
No se debe enviar la contraseña por correo; se almacena un hash mediante bcrypt. No debe confundirse un token de verificación con un token de sesión. El envío a una cola tampoco garantiza por sí solo la entrega final del SMTP. Es importante manejar expiración, reintentos y mensajes fallidos. La configuración `MAIL_HOST`, `MAIL_PORT`, `MAIL_USER`, `MAIL_PASS` y `MAIL_FROM` debe corresponder al entorno. La verificación por URL debe evitar registrar el token completo en logs.

### g) Conexiones
Intervienen `auth.controller.ts`, `jwt.service.ts`, `email.service.ts`, la plantilla EJS, `messageProducer.ts`, `messageConsumer.ts`, RabbitMQ, SMTP, MongoDB y `env.ts`. Es un ejemplo de trabajo asíncrono: HTTP registra la intención; el consumidor ejecuta la tarea externa.

**Autoevaluación:** ¿Qué significa que el backend haya creado la cuenta y encolado el correo, pero que el consumidor todavía no haya logrado enviarlo?

---

## 3. Token frente a Bearer

### a) Qué es
Un **token** es una cadena que representa información o una autorización temporal; **Bearer** es una forma de presentar un token en la cabecera HTTP `Authorization`, normalmente con el formato `Authorization: Bearer <token>`.

### b) Para qué sirve
Los tokens permiten que el servidor compruebe una acción sin pedir la contraseña en cada solicitud. El tipo de token y el contexto determinan qué acción autoriza: verificar correo, mantener una sesión, o realizar otra operación limitada.

### c) Cómo funciona
En TASS, `backend/src/services/jwt.service.ts` crea y verifica JWT. JWT significa JSON Web Token: un formato de token firmado que incluye datos llamados claims, por ejemplo el identificador del usuario, el tipo de token y fechas de expiración. La firma permite detectar modificaciones; no cifra automáticamente el contenido. Por eso no deben incluirse secretos dentro del payload.

En la verificación de correo, el token aparece como parámetro de URL (`?token=...`) y se comprueba que `payload.type === 'verify-email'`. Para endpoints protegidos, el frontend utiliza `backend?` No: el interceptor real está en `frontend/src/app/core/interceptors/auth.interceptor.ts`, que añade la cabecera `Authorization: Bearer ...` a solicitudes. El middleware del backend lee esa cabecera, verifica la sesión y aplica las comprobaciones de cuenta/rol. La URL de verificación y la cabecera Bearer son dos maneras distintas de transportar un token.

### d) Cómo se usa en TASS
El token de verificación se usa en el enlace enviado por correo. El token de autenticación se adjunta a peticiones protegidas como las de conflictos, empleados o administración. En el código de autenticación también se utilizan identificadores de sesión en Redis y una lista de revocación; por tanto, una firma JWT válida no necesariamente significa que la sesión siga permitida si fue revocada.

### e) Ejemplo aplicado a TASS
La persona abre el enlace de verificación, que contiene `?token=...`; el endpoint de verificación valida que sea de tipo `verify-email`. Después inicia sesión. El frontend guarda/obtiene el token de sesión según el servicio de autenticación y el interceptor envía `Authorization: Bearer ey...` al consultar los conflictos. Un token de verificación presentado como Bearer no debe servir para leer conflictos porque su tipo y finalidad son diferentes.

### f) Errores comunes
“Token” y “Bearer” no son sinónimos exactos: uno es el valor y el otro el esquema de presentación en la cabecera. JWT firmado no es lo mismo que información cifrada. No se debe aceptar cualquier JWT sin validar firma, expiración, tipo, estado de la cuenta y, cuando corresponda, sesión Redis. Tampoco se debe enviar un Bearer en URLs, porque puede filtrarse en historiales y logs.

### g) Conexiones
Se relaciona con `auth.interceptor.ts`, `auth.middleware.ts`, `role.middleware.ts`, `jwt.service.ts`, Redis, los guards de Angular y el correo de verificación.

**Autoevaluación:** ¿Por qué un token de verificación recibido por URL no debería autorizar una petición administrativa enviada con Bearer?

---

## 4. Flujo del botón Detectar conflictos

### a) Qué es
Es la cadena de acciones desde el clic del administrador en la interfaz hasta la ejecución de la lógica que busca relaciones que puedan representar conflictos de interés.

### b) Para qué sirve
Permite ejecutar la revisión de datos existentes y guardar nuevos hallazgos sin que el administrador tenga que inspeccionar manualmente todas las relaciones.

### c) Cómo funciona
En el frontend, la tabla y las páginas administrativas se apoyan en servicios Angular, especialmente `frontend/src/app/core/services/conflict.service.ts` y componentes bajo `frontend/src/app/pages/admin/`. La solicitud HTTP llega a las rutas de conflictos en `backend/src/routes/conflict.routes.ts`, que delegan en `conflict.controller.ts`. El controlador invoca `detectLevelOneConflicts()` del servicio `conflict.service.ts` y devuelve la cantidad y los conflictos guardados.

**Diferencia importante:** el controlador HTTP que está en el ZIP llama directamente a `detectLevelOneConflicts()`. Sin embargo, `server.ts` también configura un cron que publica un mensaje en RabbitMQ, y el consumidor de la cola `tass.conflict.detection` ejecuta esa misma función para la ejecución programada. No hay que afirmar que el botón usa RabbitMQ solo porque el cron sí lo usa; el camino real depende de la ruta actual del botón y del servicio frontend.

### d) Cómo se usa en TASS
La lógica consulta usuarios activos, carga relaciones familiares, compara pares y evita crear un conflicto ya existente. Si encuentra hallazgos nuevos, los guarda en `ConflictModel` y genera notificaciones. El controlador responde con `success`, `total` y `data`. Si no hay hallazgos nuevos, devuelve una lista vacía.

### e) Ejemplo aplicado a TASS
El administrador pulsa “Detectar conflictos”. Angular llama al servicio; el backend consulta MongoDB. Encuentra que un usuario activo declaró a un familiar que también es usuario activo y que esa pareja todavía no tiene conflicto registrado. Guarda un conflicto `PENDIENTE`, genera su código, asigna nivel y categoría, y retorna el nuevo hallazgo para actualizar la tabla.

### f) Errores comunes
No confundir “ejecutar detección” con “marcar un conflicto como resuelto”. La detección no debería duplicar conflictos existentes. Tampoco significa que cada ejecución cree un registro nuevo: si no hay nuevas relaciones, puede devolver cero. La versión de la ruta HTTP actual no está delegando en `publishToQueue`; el procesamiento asíncrono aparece explícitamente en el cron y el consumer.

### g) Conexiones
Se relaciona con `conflict.service.ts`, `ConflictModel`, `FamilyRelationship`, `Notification`, RabbitMQ para ejecuciones programadas, Redis para estadísticas/listados cacheados y el componente de tabla Angular.

**Autoevaluación:** ¿Cómo comprobarías en el código si el clic de la interfaz llama a la detección directa o publica un mensaje en RabbitMQ?

---

## 5. Cambiar un conflicto de resuelto a pendiente

### a) Qué es
Es una operación de actualización del estado de un conflicto ya registrado, que permite reabrir un caso que se había marcado como resuelto.

### b) Para qué sirve
La revisión administrativa puede concluir que el problema no quedó realmente solucionado o que hace falta una nueva actuación. Reabrirlo conserva el registro y devuelve el caso a una bandeja que requiere atención.

### c) Cómo funciona
El componente Angular recoge el clic y envía el identificador del conflicto y el estado solicitado al servicio frontend. En backend, `updateConflictStatusController()` valida que el identificador tenga formato ObjectId, lee `estado` del cuerpo y llama a `updateConflictStatus()` en `backend/src/services/conflict.service.ts`. El servicio busca el documento. Si no existe, rechaza la operación. Permite únicamente `PENDIENTE` o `RESUELTO`; si se cambia a `PENDIENTE`, exige que el estado actual sea `RESUELTO`. Al reabrir, asigna `fechaResolucion = null`; al resolver, asigna la fecha actual. Después guarda el documento y responde con el conflicto actualizado.

### d) Cómo se usa en TASS
El estado de negocio vive en MongoDB, no solamente en el color del botón. El frontend debe actualizar la tabla usando la respuesta o volver a consultar los datos. Si existe una caché de listados o estadísticas, puede mostrar valores anteriores hasta que expire el TTL: la documentación de Redis señala que los datos de conflictos no se invalidan automáticamente en todas las escrituras.

### e) Ejemplo aplicado a TASS
El conflicto `TASS-0007` estaba `RESUELTO`. El administrador encuentra una evidencia nueva y elige “Volver a pendiente”. Angular manda `estado: 'PENDIENTE'`. El servicio comprueba el estado anterior, borra `fechaResolucion` y guarda el cambio. Las métricas futuras ya no deben contarlo como resuelto; sin embargo, la tasa que se muestra puede quedar cacheada hasta cinco minutos si no se invalida la clave correspondiente.

### f) Errores comunes
Cambiar el estado en la interfaz sin persistirlo en MongoDB solo altera la apariencia. También es un error permitir cualquier cadena como estado. La regla actual no permite usar esta función para mover un caso desde cualquier estado a pendiente: requiere estado actual `RESUELTO`. Debe revisarse si el endpoint está protegido por autenticación y rol en el montaje completo de rutas. Además, al reabrir, se borra la fecha de resolución; si se necesita un historial de todas las resoluciones, eso debería registrarse en una auditoría independiente.

### g) Conexiones
Se conecta con el modelo `Conflict`, el controlador, la tabla Angular, estadísticas del dashboard, exportaciones y caché Redis.

**Autoevaluación:** ¿Qué dos cambios de datos hace el servicio al reabrir un conflicto y por qué importa limpiar `fechaResolucion`?

---

## 6. Descarga de PDF y Excel con datos actuales

### a) Qué es
Es la generación de un archivo descargable a partir de los conflictos que existen en la base de datos cuando se procesa la solicitud.

### b) Para qué sirve
Permite compartir, archivar o analizar los conflictos fuera de la aplicación. PDF prioriza la presentación para lectura o impresión; Excel facilita filtrar, ordenar y trabajar con filas y columnas.

### c) Cómo funciona
El controlador `generateConflictReportController()` lee `formato` del cuerpo. Para `pdf`, llama a `generateReportThroughQueue('pdf')`; para `excel`, llama a `generateReportThroughQueue('excel')`. Esa función usa RabbitMQ con patrón RPC: el HTTP envía una petición con identificador de correlación, espera la respuesta del consumidor y recibe el contenido binario. El consumidor invoca `generateConflictPdf()` o `generateConflictExcel()`. Ambos servicios consultan `ConflictModel` al generar el documento, en vez de tomar una tabla antigua del navegador. El controlador establece `Content-Type` y `Content-Disposition: attachment` y envía los bytes.

PDF usa PDFKit; Excel usa ExcelJS. El PDF consulta `ConflictModel.find().sort({ fechaDeteccion: -1 }).lean()`, crea encabezado, resumen y detalle. Excel crea una hoja con columnas, formato, anchos y filas. El hecho de que la consulta se haga en el momento de generar el informe permite incluir cambios ya guardados antes de esa consulta.

### d) Cómo se usa en TASS
La nueva ruta de reportes usa RabbitMQ para delegar la generación a un consumer y responder al mismo HTTP cuando el archivo esté listo. Por eso la interfaz puede esperar la respuesta binaria como una descarga, aunque el trabajo lo haya ejecutado otro consumidor.

### e) Ejemplo aplicado a TASS
Un administrador resuelve un conflicto y, después de guardarse el cambio, descarga Excel. El consumidor consulta MongoDB y construye el archivo con el estado vigente al momento de esa lectura. Si descarga antes de que se complete la escritura, o si consulta una pantalla que usa caché, puede haber una diferencia temporal. “Datos actuales” significa datos persistidos visibles para la consulta de generación, no cambios que todavía no se guardaron.

### f) Errores comunes
No es lo mismo exportar el arreglo que ya está en la tabla que consultar la base al generar el archivo. No se debe declarar que el archivo está actualizado si se construye a partir de datos cacheados o no se espera la respuesta RPC. Los informes pueden contener datos personales: hay que proteger el endpoint, controlar roles y evitar exponerlos en logs. También debe contemplarse timeout o error del consumidor.

### g) Conexiones
Se conecta con `conflict.controller.ts`, `report-rpc.service.ts`, `messageProducer.ts`, `messageConsumer.ts`, las colas RabbitMQ, `conflict-report-PDF.service.ts`, `conflict-report-Excel.service.ts`, MongoDB y la interfaz Angular.

**Autoevaluación:** ¿Por qué un reporte puede tener datos más recientes que una tabla que aún muestra una respuesta cacheada?

---

## 7. Detección de conflictos nuevos

### a) Qué es
Es el proceso que identifica una relación o combinación nueva que cumple las reglas de conflicto de interés y crea un registro para revisión.

### b) Para qué sirve
Evita duplicar el trabajo manual y permite que el sistema detecte casos cuando cambia la información de usuarios o sus relaciones familiares.

### c) Cómo funciona
`detectLevelOneConflicts()` en `backend/src/services/conflict.service.ts` consulta usuarios con `estado: 'ACTIVO'`, obtiene datos de la empresa proveedora cuando aplica, crea un mapa por ID, carga las relaciones familiares, y recorre esas relaciones. Descarta relaciones consigo mismo y pares que no tengan ambos usuarios activos. Calcula el nivel según los tipos de vinculación, determina categoría, comprueba si ya existe un conflicto y construye los datos del nuevo conflicto. Se asigna `PENDIENTE`, `fechaDeteccion`, código, involucrados, coincidencia `RELACION FAMILIAR`, descripción, evidencias, notas y registro de auditoría inicial. Al final inserta los conflictos nuevos en MongoDB y crea notificaciones.

### d) Cómo se usa en TASS
El resultado de la detección es una colección de conflictos persistidos. La lógica de negocio decide qué relaciones son relevantes; el controlador decide cómo responder HTTP, y el consumer puede invocar el mismo servicio en el trabajo programado. MongoDB es la fuente permanente; Redis puede cachear listados y estadísticas, pero no sustituye la colección de conflictos.

### e) Ejemplo aplicado a TASS
La persona A, activa, registra a la persona B como familiar. B también tiene cuenta activa. Durante una detección, el sistema encuentra esa relación y confirma que la pareja no tiene ya un conflicto. Crea un documento `Conflict` con dos objetos en `involucrados`, el parentesco declarado y estado `PENDIENTE`, luego crea una notificación para que el caso se revise.

### f) Errores comunes
Detectar una relación no demuestra automáticamente una infracción; crea un posible conflicto que debe revisarse. Hay que evitar pares duplicados y considerar las relaciones declaradas en ambos sentidos. En el código revisado, la clave de pareja y la comprobación de duplicado merecen especial atención para asegurar que A-B y B-A no se traten como dos conflictos distintos. También debe contemplarse una condición de carrera si dos procesos detectan e insertan el mismo conflicto simultáneamente; los índices únicos y el manejo de duplicados son importantes.

### g) Conexiones
Se relaciona con relaciones familiares, `ConflictModel`, niveles/categorías, notificaciones, dashboard, reportes y cron/RabbitMQ.

**Autoevaluación:** ¿Por qué el sistema debe comprobar si el conflicto ya existe antes de insertar uno nuevo?

---

## 8. Reconocimiento de una relación familiar nueva

### a) Qué es
Es el registro de una relación entre un usuario declarante y una persona familiar, con un parentesco, que posteriormente puede ser utilizado por el motor de detección.

### b) Para qué sirve
La relación familiar aporta el dato que permite al sistema descubrir que dos personas relacionadas podrían crear un conflicto según sus roles o vínculos con la organización.

### c) Cómo funciona
Los archivos de backend incluyen `FamilyDeclaration`, `FamilyRelationship`, `family-declaration.controller.ts`, `family-relationship.controller.ts` y `family-relationship.service.ts`. El controlador recibe la declaración, valida los datos y el servicio persiste la relación. El motor `detectLevelOneConflicts()` consulta las relaciones guardadas en `familyRelationshipModel`; no puede detectar una relación que nunca se guardó o que está en otra fuente no consultada.

La secuencia conceptual es: el usuario declara al familiar → backend valida identidad y parentesco → guarda la declaración/relación en MongoDB → una detección posterior consulta esa relación → si ambas personas están activas y no existe conflicto equivalente, se crea un conflicto pendiente.

### d) Cómo se usa en TASS
La relación familiar no es por sí misma el documento `Conflict`. Es un dato de entrada que el motor interpreta. Esto permite que la información declarada exista antes de que se ejecute la detección automática, ya sea por el botón o por el cron programado.

### e) Ejemplo aplicado a TASS
Un usuario declara que su familiar es su hermana. El backend guarda los IDs de ambos y el parentesco. Cuando el motor corre, busca esos IDs en el mapa de usuarios activos. Si ambos existen y la pareja aún no está registrada como conflicto, el sistema crea un conflicto que describe el parentesco y requiere revisión administrativa.

### f) Errores comunes
No asumir que guardar una relación familiar dispara instantáneamente la detección; eso depende de si el endpoint también llama al motor o solo guarda el dato. Tampoco confundir la persona familiar con una cuenta autorizada: son conceptos diferentes. Si la relación es inválida, apunta a un usuario inexistente o la cuenta está inactiva, la detección actual puede omitirla.

### g) Conexiones
Se conecta con formularios Angular, servicios familiares, `FamilyRelationship`, `User`, `conflict.service.ts`, notificaciones y el proceso de detección programado.

**Autoevaluación:** ¿Qué debe ocurrir entre guardar una relación familiar y que aparezca en la tabla de conflictos si el endpoint solo almacena la relación?

---

## 9. Mantener fija la sección seleccionada

### a) Qué es
Es una técnica de interfaz que identifica qué apartado de navegación corresponde a la ruta actual y le aplica un estilo visual de “activo”.

### b) Para qué sirve
Ayuda al usuario a saber en qué módulo está —por ejemplo, conflictos, empleados, proveedores o configuración— sin tener que recordar qué enlace abrió.

### c) Cómo funciona
Angular Router mantiene la ruta activa. Los enlaces pueden usar `routerLink` para navegar y `routerLinkActive` o una comparación explícita con la ruta para marcar el elemento. El estado visual suele ser una clase CSS como `active`. En una navegación por rutas, el elemento activo debería derivarse de la URL actual, no de un clic aislado: si el usuario actualiza el navegador o entra directamente por un enlace, la sección debe seguir resaltada.

### d) Cómo se usa en TASS
La navegación compartida se encuentra bajo `frontend/src/app/shared/components/navbar/` y las rutas en `frontend/src/app/app.routes.ts`. El patrón a comprobar es la asociación entre `routerLink`, ruta configurada y clase CSS activa. En el componente exacto conviene revisar la plantilla y el TypeScript juntos para identificar si usa `routerLinkActive` o una variable propia; ambas estrategias son posibles, pero la ruta debe ser la fuente de verdad.

### e) Ejemplo aplicado a TASS
El administrador navega a la página de conflictos. La URL cambia a la ruta de administración de conflictos y el enlace correspondiente queda con la clase `active`. Si recarga la página, Angular vuelve a reconocer la ruta y debe resaltar el mismo apartado sin que el usuario vuelva a pulsarlo.

### f) Errores comunes
Una variable que se actualiza solo en el evento de clic puede desincronizarse si el usuario usa Atrás/Adelante del navegador. Comparar rutas con subcadenas poco precisas puede resaltar dos enlaces al mismo tiempo. La clase activa tampoco es seguridad: ocultar un enlace no impide que alguien llame la API directamente.

### g) Conexiones
Se relaciona con Angular Router, `app.routes.ts`, navbar, guards de autenticación/rol y CSS. Los guards controlan acceso; el estilo activo solo informa visualmente.

**Autoevaluación:** ¿Por qué la sección activa debe depender de la ruta y no únicamente del último clic?

---

## 10. Una tabla y vistas distintas según el rol

### a) Qué es
Es reutilizar una estructura de tabla o componente para mostrar distintos subconjuntos de información o acciones según el rol del usuario autenticado.

### b) Para qué sirve
Reduce duplicación de interfaz y mantiene una presentación consistente, aunque un administrador pueda ver acciones que un usuario común no puede ejecutar.

### c) Cómo funciona
El frontend puede leer el rol desde el estado de autenticación y usar condiciones de plantilla para mostrar u ocultar botones, columnas o secciones. Angular guards (`auth.guard.ts`, `roles.guard.ts`) pueden impedir navegación a rutas protegidas. En backend, `auth.middleware.ts` y `role.middleware.ts` deben comprobar el token y los permisos en cada endpoint sensible. La seguridad real debe estar en backend; el frontend solo mejora la experiencia.

### d) Cómo se usa en TASS
La aplicación tiene páginas para administración, superadministración y usuario, además de componentes compartidos como `frontend/src/app/pages/admin/components/conflict-table/`. El componente común puede representar conflictos, mientras las páginas que lo contienen determinan qué acciones se ofrecen. Debe confirmarse la lógica exacta de roles en el componente actual antes de afirmar que todas las vistas son una sola tabla compartida: existen páginas distintas por rol y un componente de tabla administrativo.

### e) Ejemplo aplicado a TASS
Un administrador ve columnas de estado y botones para resolver o reabrir un conflicto. Un usuario ordinario podría ver información limitada o una página de inicio distinta. Aunque alguien manipule el HTML para hacer visible el botón de “Resolver”, la API debe rechazar la petición si el rol no está autorizado.

### f) Errores comunes
Ocultar un botón no es autorización. Compartir un componente no implica compartir los mismos permisos. También es un error duplicar la lógica de permisos en muchos lugares sin una regla central, porque una pantalla puede quedar desactualizada frente a otra.

### g) Conexiones
Se conecta con `auth.service.ts`, guards, interceptor Bearer, middleware de roles en backend, rutas y componente de tabla.

**Autoevaluación:** ¿Qué impediría que un usuario no administrador resolviera un conflicto si logra enviar la petición manualmente?

---

## 11. Tasa de resolución y tiempo promedio de resolución

### a) Qué es
La tasa de resolución es un indicador porcentual que estima qué proporción de conflictos se ha resuelto; el tiempo promedio es la media de días transcurridos entre detección y resolución de los casos resueltos que tienen ambas fechas.

### b) Para qué sirve
Permite evaluar la carga de trabajo y la rapidez de respuesta administrativa. Debe interpretarse con cuidado: una tasa alta no siempre significa buena gestión si se descartan casos indebidamente, y un promedio puede ocultar casos excepcionalmente antiguos.

### c) Cómo funciona
En `getDashboardStats()` de `backend/src/services/conflict.service.ts`, la tasa base se calcula como `(conflictosResueltos / totalConflictos) * 100`, o cero si no hay conflictos. Después resta una penalización por pendientes antiguos. Para cada conflicto pendiente, calcula los días desde `fechaDeteccion`; si han pasado más de dos días, suma tres puntos de penalización por cada día adicional. La tasa final es `Math.max(0, tasaBase - penalizacion)`. El resultado se redondea a dos decimales.

El tiempo promedio se calcula solo con conflictos cuyo estado sea `RESUELTO` y `fechaResolucion` no sea nula. Para cada uno: `(fechaResolucion - fechaDeteccion) / (1000 * 60 * 60 * 24)`. Después suma los tiempos y divide por la cantidad de conflictos considerados. Si no hay casos válidos, queda en cero.

### d) Cómo se usa en TASS
Las estadísticas incluyen total de usuarios activos, total de conflictos, conflictos de alto riesgo, pendientes, resueltos, tasa, estado descriptivo, penalización y tiempo promedio. Se cachean con TTL de conflictos, por lo que pueden tardar en reflejar una actualización.

### e) Ejemplo aplicado a TASS
Si hay 20 conflictos y 10 están resueltos, la tasa base es 50 %. Si los pendientes antiguos acumulan una penalización de 6 puntos, la tasa presentada sería 44 %. Si tres conflictos resueltos tardaron 2, 4 y 6 días, el promedio sería `(2 + 4 + 6) / 3 = 4 días`.

### f) Errores comunes
No llamar “tasa simple” al valor final sin explicar la penalización. No incluir pendientes en el promedio de resolución, porque aún no tienen una fecha final. Si se reabre un conflicto, el código pone `fechaResolucion` en `null`, por lo que deja de contarse como resuelto. Debe revisarse si la fórmula de penalización es una regla de negocio aprobada: puede llegar a restar muchos puntos, aunque el resultado se limita a cero.

### g) Conexiones
Se relaciona con estados de conflictos, fechas, `getDashboardStats()`, caché Redis, componentes KPI y datos exportados.

**Autoevaluación:** ¿Por qué el promedio de resolución solo usa casos resueltos con fecha de resolución y por qué la tasa TASS no es únicamente el porcentaje de resueltos?

---

## 12. Qué contiene cada columna del Excel

### a) Qué es
Es la explicación del significado y origen de cada columna que genera `conflict-report-Excel.service.ts`.

### b) Para qué sirve
Permite interpretar el archivo exportado sin adivinar qué representa cada valor y comprobar que las filas corresponden a los registros almacenados.

### c) Cómo funciona
El servicio consulta los conflictos en MongoDB y construye una hoja ExcelJS. La implementación incluye encabezados y columnas para identificar el conflicto, describir su categoría y nivel, reflejar fechas y estado, explicar coincidencias y listar personas involucradas. Los datos se convierten a texto cuando hace falta para que la hoja sea legible. Las fechas sin valor se muestran como “No registrada”; listas de coincidencias e involucrados se formatean en varias líneas.

### d) Cómo se usa en TASS
En el archivo de servicio, la fila de datos agrega valores como código, categoría, nivel, estado, fechas, descripción, coincidencias, involucrados y responsable presentado como “Administrador”. Las anchuras de columnas y `wrapText` ayudan a que el texto largo se ajuste a la celda. La cabecera exacta y su orden deben cotejarse con el arreglo `worksheet.addRow(...)` y `worksheet.columns` de la versión incluida; no conviene renombrar una columna interpretando su intención sin revisar ese orden.

### e) Ejemplo aplicado a TASS
Una fila puede contener el código del conflicto, el nivel `ALTO`, estado `PENDIENTE`, fecha de detección, “No registrada” para fecha de resolución, descripción del caso, coincidencia `RELACION FAMILIAR` y dos personas involucradas con sus datos. Esa fila es un reporte del conflicto, no una prueba por sí sola de que exista una falta confirmada.

### f) Errores comunes
No confundir “fecha de detección” con “fecha de declaración familiar” ni “fecha de resolución” con la fecha de exportación. Un campo `No registrada` puede significar que el dato no existe, no que la exportación falló. Los datos de documento, correo y teléfono son sensibles: compartir el archivo exige las mismas precauciones que compartir la base. Si la columna responsable está fijada a “Administrador”, no debe asumirse que representa a la persona real que resolvió cada caso; sería una etiqueta fija salvo que el código la derive de datos de auditoría.

### g) Conexiones
Se conecta con `ConflictModel`, el servicio de Excel, el controlador de reportes, RabbitMQ RPC y las reglas de privacidad/roles.

**Autoevaluación:** ¿Qué diferencia hay entre `fechaDeteccion`, `fechaResolucion` y la fecha en que se generó el archivo?

---

## 13. Configuración local, pruebas y producción

### a) Qué es
Es el mecanismo para ejecutar el mismo código con valores distintos según el entorno, por ejemplo desarrollo local, preproducción o producción.

### b) Para qué sirve
Evita conectar por accidente un entorno de pruebas con bases, correos o claves de producción. También permite cambiar puertos, URLs y credenciales sin editar el código fuente.

### c) Cómo funciona
En backend, `src/config/env.ts` lee `NODE_ENV`, construye el nombre `.env.${nodeEnv}` y carga el archivo si existe. Luego valida que estén presentes `MONGO_URI`, `FRONTEND_URL` y `JWT_SECRET`, y exporta la configuración. `package.json` define scripts como `dev:local`, `dev`, `start:staging` y `start:prod`. Docker Compose también usa `.env.dev` como `env_file` y sustitución de variables para configurar servicios.

En frontend hay archivos de entorno bajo `src/enviroments/` y configuraciones de build Angular en `angular.json`. El Dockerfile acepta `FRONTEND_ENV` y ejecuta `ng build --configuration=...`. Son dos mecanismos distintos: variables del proceso backend y configuraciones de compilación frontend. Las variables incluidas en el bundle del frontend no son secretos, porque llegan al navegador.

### d) Cómo se usa en TASS
Compose fija `NODE_ENV: dev` para el servicio backend de la configuración revisada. El backend carga `.env.dev` desde el directorio de trabajo si está disponible, pero Compose ya inyecta variables desde su `env_file` y `environment`. Para producción se debe definir un archivo/secretos correctos y configurar `FRONTEND_ENV` y URLs adecuadas.

### e) Ejemplo aplicado a TASS
En local, el frontend puede apuntar a `http://localhost:3000`; dentro de Compose, el contenedor frontend debe llamar al backend por `http://backend:3000` a través de Nginx. Si se compila el frontend con una URL localhost equivocada, el navegador del usuario intentará llamar a su propia máquina, no al contenedor backend.

### f) Errores comunes
El nombre `NODE_ENV=production` no transforma por sí solo todos los valores en configuración segura. Tampoco debe confundirse `env_file` con el archivo que el propio `dotenv` busca dentro del contenedor. Una variable de entorno del frontend puede ser pública. El código actual valida algunas variables de backend, pero usa aserciones `!` para otras variables de correo, lo que no comprueba necesariamente en tiempo de ejecución que existan.

### g) Conexiones
Se relaciona con `env.ts`, `server.ts`, `.env.dev`, `.env.production`, Compose, Dockerfiles y `angular.json`.

**Autoevaluación:** ¿Por qué una URL interna como `http://backend:3000` funciona entre contenedores, pero normalmente no es una URL que el navegador de Windows pueda resolver?

---

## 14. Winston frente a console.log

### a) Qué es
`console.log` escribe texto de depuración en la salida estándar; Winston es una biblioteca de logging que permite registrar eventos con niveles, estructura, marcas de tiempo y varios destinos.

### b) Para qué sirve
En una aplicación con backend, base de datos, Redis, RabbitMQ y tareas programadas, no basta con imprimir frases sueltas. Hace falta saber qué ocurrió, cuándo, en qué módulo y con qué contexto, sin registrar secretos ni datos personales innecesarios.

### c) Cómo funciona
`console.log('hola')` produce una salida textual. Winston crea registros con campos, por ejemplo `level`, `message`, `timestamp`, `event` y metadatos. Los transports deciden dónde se envían: consola, archivo u otro destino. En `src/utils/logger.ts`, Winston está configurado con un transport de consola y un archivo rotativo diario.

### d) Cómo se usa en TASS
El proyecto importa `logInfo` y `logError` para registrar eventos como `database.connected`, `rabbitmq.connected`, `cache.hit` y fallos de conexión. Esos nombres estables permiten buscar un tipo de evento entre diferentes ejecuciones.

### e) Ejemplo aplicado a TASS
Con `console.log('falló Redis')` solo se obtiene una frase y quizá no se sabe qué operación falló. Con `logError('redis.connection.failed', error, { codigo: 'T502' })`, el registro contiene el evento y el código interno, y la función evita guardar el mensaje completo del error en el campo de error que construye ella misma.

### f) Errores comunes
Winston no arregla errores; solo los registra. Tampoco garantiza por sí solo que los archivos persistan después de destruir un contenedor: la ruta configurada actualmente usa el directorio temporal del sistema. No se deben registrar contraseñas, tokens, documentos o contenido de mensajes privados solo porque la biblioteca lo permita.

### g) Conexiones
Se conecta con `logger.ts`, `errorCatalog.ts`, el middleware de errores, servicios de MongoDB/Redis/RabbitMQ y Docker logs.

**Autoevaluación:** ¿Qué información útil ofrece un evento estructurado de Winston que se pierde fácilmente en una frase de `console.log`?

---

## 15. Cada funcionalidad de logger.ts

### a) Qué es
`backend/src/utils/logger.ts` es el módulo central que crea el logger Winston y expone funciones sencillas para registrar información y errores.

### b) Para qué sirve
Centraliza el formato de logs para que los demás módulos no tengan que configurar Winston por separado. También ayuda a mantener nombres de eventos consistentes y a reducir el riesgo de imprimir accidentalmente un error completo con datos sensibles.

### c) Cómo funciona
`LogContext` define un objeto de contexto cuyos valores pueden ser cadenas, números o booleanos. `DailyRotateFile` crea archivos con nombre `tass-backend-%DATE%.log` dentro de `tmpdir()`, cambia el archivo según la fecha, limita cada archivo a 20 MB, conserva 14 días y comprime archivos antiguos. En el formato del archivo se copia `info.message` a `mensaje`, se agrega `servicio: 'tass-backend'` y el entorno leído desde `NODE_ENV`, y luego se añaden timestamp y JSON.

`createLogger({ level: 'info' })` establece el nivel mínimo. El transport de consola imprime timestamp y JSON; el transport rotativo escribe al archivo. `logInfo(event, context = {})` registra nivel `info`, mensaje, `event` y el contexto. `logError(event, error, context = {})` obtiene el nombre de la excepción si `error instanceof Error`; de lo contrario usa `UnknownError`. Registra nivel `error`, evento, contexto y un objeto `error` con el nombre, pero no copia el stack ni el mensaje completo del error.

### d) Cómo se usa en TASS
Las funciones se importan desde módulos de controladores, servicios y configuración. Por ejemplo, cuando Redis falla, se registra `redis.connection.failed` con el código T502; cuando la detección falla, se registra `conflict.detection.failed`.

### e) Ejemplo aplicado a TASS
`logInfo('rabbitmq.message.published', { queue: 'tass.email.notification' })` permite buscar publicaciones de correo sin guardar el correo del usuario ni el token de verificación. `logError('database.connection.failed', error)` deja evidencia de que falló la conexión y del tipo de error.

### f) Errores comunes
El archivo rotativo está en el directorio temporal del sistema, que puede borrarse o no sobrevivir a la recreación del contenedor. Si se requiere retención operativa, debe configurarse una ruta persistente o un agregador externo. La función `logError` no registra stack trace, así que se sacrifica detalle de depuración a cambio de una salida más controlada. El contexto debe mantenerse pequeño y sin secretos.

### g) Conexiones
Se relaciona con `ErrorCatalog`, los eventos de RabbitMQ, Redis, salud, detección, el middleware de errores y el entorno Docker.

**Autoevaluación:** ¿Qué ventajas y limitaciones tiene registrar solo el nombre del error y no su mensaje ni stack completo?

---

## 16. Por qué funciona logError(...) sin function al inicio

### a) Qué es
`logError(...)` es una llamada a una función que ya fue declarada y exportada desde otro archivo; no es una declaración de función nueva en el lugar donde se usa.

### b) Para qué sirve
Permite reutilizar una implementación común. Cada controlador no tiene que volver a escribir cómo se crea un log de error; solo indica el evento, el error y los datos adicionales.

### c) Cómo funciona
En `logger.ts` aparece `export function logError(event: string, error: unknown, context: LogContext = {}): void { ... }`. La palabra `export` permite que otro módulo la importe. En otro archivo, `import { logError } from '../utils/logger.js';` trae esa referencia al ámbito del archivo. Después `logError('evento', error)` ejecuta la función. La sintaxis `function logError(...) {}` define una función; `logError(...)` la llama.

El proyecto usa TypeScript con módulos ES y en el código fuente escribe imports con extensión `.js`, un patrón común cuando TypeScript se compila a JavaScript ESM.

### d) Cómo se usa en TASS
`health.routes.ts`, `auth.controller.ts`, `conflict.service.ts`, `redis.ts` y `rabbitmq.ts` importan las funciones de logging. Cada uno las invoca cuando ocurre un evento relevante. La implementación única determina el formato de todos esos registros.

### e) Ejemplo aplicado a TASS
Dentro de `redis.ts`, el evento de error hace `logError('redis.connection.failed', error, { codigo: ErrorCatalog.T502.codigo, mensaje: ErrorCatalog.T502.descripcion })`. No define otra función llamada `logError`; llama a la función importada y le pasa tres argumentos.

### f) Errores comunes
No se debe escribir `function logError(...)` cada vez que se quiera registrar un evento. Tampoco puede usarse una función sin importarla o declararla, salvo que exista en el ámbito global —y no es el caso que se busca aquí—. Los argumentos deben respetar la firma: evento, error y contexto opcional.

### g) Conexiones
Se conecta con módulos ES, `export`/`import`, TypeScript, compilación y `logger.ts`.

**Autoevaluación:** ¿Puedes distinguir una línea que define `logError` de una línea que simplemente la ejecuta?

---

## 17. Archivo health.routes.ts de principio a fin

### a) Qué es
Es un router Express que expone una ruta de comprobación de salud y verifica si MongoDB está conectado y puede responder a un ping.

### b) Para qué sirve
Permite a Docker y a las herramientas de operación comprobar que el backend no solo está escuchando, sino que puede comunicarse con su base de datos principal.

### c) Cómo funciona
El archivo importa `Router`, el tipo `Response`, Mongoose y `logError`. La función `createHealthRouter()` recibe una conexión con `readyState` y `db`; por defecto usa `mongoose.connection`. La inyección del parámetro permite probar el router con una conexión controlada.

Al recibir GET en la ruta `/`, primero revisa si `readyState !== 1` o no existe `db`. En ese caso responde HTTP 503 con JSON `status: unavailable` y `database: unavailable`. Si la conexión parece lista, ejecuta `connection.db.admin().ping()`. Si el ping funciona, devuelve HTTP 200 con `status: ok` y `database: connected`. Si lanza una excepción, registra `health.mongo.ping_failed` y devuelve HTTP 503. Finalmente exporta `healthRouter = createHealthRouter()`.

En `server.ts`, el router se monta con `app.use('/health', healthRouter)`, por lo que la URL completa es `/health`. El healthcheck de Compose usa precisamente `/health`.

### d) Cómo se usa en TASS
Es una comprobación de disponibilidad centrada en MongoDB. No comprueba explícitamente que Redis, RabbitMQ, SMTP, las colas o la generación PDF estén operativos. Por tanto, un `200` indica que el backend puede hacer ping a MongoDB, no que todas las funcionalidades de TASS estén saludables.

### e) Ejemplo aplicado a TASS
Si MongoDB está apagado, el backend puede responder `503` en `/health`, y Docker marca el contenedor como `unhealthy` después de los intentos configurados. Si MongoDB responde al ping, la ruta devuelve `200` aunque RabbitMQ esté fallando; ese límite debe tenerse presente al diagnosticar reportes o correos.

### f) Errores comunes
No confundir `healthRouter` con el servidor completo: solo define la ruta. No confundir `readyState === 1` con una prueba definitiva de la base; por eso el código hace además `ping()`. Tampoco interpretar un `200` como garantía de que el flujo de correo o los reportes RPC funcionan.

### g) Conexiones
Se conecta con `server.ts`, `mongoose.connect`, el healthcheck de Dockerfile/Compose, Winston y las pruebas `tests/health.routes.test.js`.

**Autoevaluación:** ¿Qué dependencia comprueba realmente `/health` y cuáles quedan fuera de esa prueba?

---

## 18. Archivos Docker y, en especial, Compose

### a) Qué es
Docker empaqueta y ejecuta aplicaciones en contenedores; `compose.yml` describe varios servicios y cómo se conectan entre sí.

### b) Para qué sirve
TASS necesita más que el backend: necesita MongoDB, Redis, RabbitMQ y el frontend. Compose permite levantar ese conjunto con una red, variables, volúmenes, límites de recursos, puertos y healthchecks definidos en un solo archivo.

### c) Cómo funciona
El `Dockerfile` del backend usa una etapa `build` con Node para instalar dependencias y compilar TypeScript, y otra etapa para instalar dependencias de producción y copiar `dist`. El `Dockerfile` del frontend compila Angular en una etapa Node y luego copia los archivos estáticos a una imagen Nginx. Los Dockerfiles de Mongo, Redis y RabbitMQ personalizan la imagen o su configuración.

`compose.yml` declara servicios `backend`, `mongodb`, `redis`, `rabbitmq` y `frontend`. `build` indica dónde está el Dockerfile; `environment` y `env_file` inyectan configuración; `ports` publica un puerto del host hacia el contenedor; `expose` documenta/expone puertos para la red del servicio sin publicarlos al host; `depends_on` ordena dependencias y puede esperar una condición `service_healthy`; `networks` conecta servicios; `volumes` conserva datos fuera del ciclo de vida del contenedor; `healthcheck` define una prueba repetida; `cpus` y `mem_limit` limitan recursos.

### d) Cómo se usa en TASS
La red `tass-network` permite que los contenedores se comuniquen por nombres de servicio. MongoDB y RabbitMQ tienen volúmenes persistentes en el Compose revisado; Redis no tiene volumen de datos y se utiliza como caché temporal. El frontend publica el puerto 80 del contenedor en el puerto host configurado, por defecto 11001. El backend publica el 3000 del contenedor en el 3000 del host.

### e) Ejemplo aplicado a TASS
Al ejecutar `docker compose --env-file .env.dev up -d --build`, Compose construye imágenes y levanta los servicios en segundo plano. El frontend espera a que el backend pase su healthcheck. El backend espera a que MongoDB esté saludable, y se conecta a Redis/RabbitMQ durante el arranque. `-d` significa detached: deja los contenedores ejecutándose en segundo plano.

### f) Errores comunes
`depends_on` sin condición saludable no garantiza que una aplicación esté lista para aceptar operaciones. `expose` no equivale a publicar un puerto al host. El contenedor no debe usar `localhost` para alcanzar otro contenedor: localhost apunta al propio contenedor. Las variables obligatorias de Compose deben estar resueltas antes de levantar el stack.

### g) Conexiones
Se conecta con todos los Dockerfiles, Nginx, `env.ts`, healthchecks, MongoDB, Redis y RabbitMQ.

**Autoevaluación:** ¿Qué diferencia práctica existe entre `ports`, `expose`, `volumes` y `depends_on: condition: service_healthy`?

---

## 19. Por qué no publicar Mongo en el host

### a) Qué es
Publicar el puerto de MongoDB significa crear un mapeo desde un puerto de la máquina anfitriona, por ejemplo `localhost:27017`, hacia el puerto 27017 del contenedor.

### b) Para qué sirve evitarlo
Si solo el backend necesita MongoDB, no hace falta que Windows u otros equipos accedan directamente a la base. No publicar el puerto reduce la superficie de exposición y evita conflictos con otra instancia que ya use 27017.

### c) Cómo funciona
Entre contenedores en la misma red, el backend puede conectar a `mongodb:27017` usando DNS interno de Compose. `ports: - "27017:27017"` es lo que publica Mongo en el host; eliminar esa sección impide el acceso mediante `localhost:27017`, pero no bloquea las conexiones internas autorizadas por la red.

### d) Cómo se usa en TASS: observación importante
El comentario citado (“se retiró la publicación del puerto Mongo en el host...”) **no coincide con el `compose.yml` que vino en el ZIP revisado**: ese archivo contiene actualmente `ports: - "27017:27017"` en el servicio `mongodb`. Por tanto, en esta copia sí se está publicando el puerto. El motivo de seguridad explicado en el comentario es válido como recomendación, pero no describe el estado del archivo entregado. Para que se cumpla, habría que quitar `ports` del servicio MongoDB y mantener la red interna.

### e) Ejemplo aplicado a TASS
Si el puerto 27017 de Windows ya está ocupado, el mapeo puede fallar al iniciar el contenedor. Si MongoDB no necesita una conexión directa desde una herramienta local, el backend puede seguir conectándose a `mongodb:27017` dentro de `tass-network` sin mapear el puerto al host. Para usar Compass desde Windows, se necesitaría publicar el puerto de forma deliberada y proteger la instancia con autenticación y controles adecuados.

### f) Errores comunes
Quitar `ports` no desconecta Mongo del backend; elimina la entrada desde el host. `expose` no abre el puerto en Windows. Además, no debe afirmarse que la base está “sin autenticación” solo por ver el Compose: hay variables de usuario/contraseña de inicialización y un healthcheck autenticado; la seguridad real también depende de la configuración de Mongo y de que las credenciales sean efectivas.

### g) Conexiones
Se relaciona con redes Docker, DNS interno, seguridad de servicios, conflictos de puertos y herramientas como MongoDB Compass.

**Autoevaluación:** En el archivo actual, ¿qué línea demuestra que Mongo sí está publicado en el host y qué habría que cambiar para retirarlo?

---

## 20. Probar un healthcheck con un contenedor temporal

### a) Qué es
Es ejecutar una comprobación desde un contenedor efímero, sin convertir ese contenedor en parte permanente de la aplicación, para verificar conectividad y comportamiento de una ruta.

### b) Para qué sirve
Permite reproducir el entorno de red real de Docker. Una prueba desde Windows puede fallar por DNS o puertos aunque el servicio funcione entre contenedores; probar desde la red Compose permite comprobar el camino que usa el healthcheck.

### c) Cómo funciona
El healthcheck del backend usa Node para ejecutar `fetch('http://backend:' + PORT + '/health')` y devuelve código 0 si la respuesta es exitosa o 1 si falla. Un contenedor temporal conectado a `tass-network` puede hacer una solicitud a `http://backend:3000/health` y mostrar el estado HTTP. Si el contenedor temporal no está conectado a esa red, no podrá resolver el nombre `backend`.

### d) Cómo se usa en TASS
La prueba debe distinguir entre comprobar la ruta, comprobar el estado Docker y comprobar todas las dependencias. `docker compose ps` muestra el estado del healthcheck del servicio; los logs ayudan a entender el motivo. El contenedor temporal es útil para probar DNS y HTTP sin instalar herramientas en la imagen de producción.

### e) Ejemplo aplicado a TASS
Se puede ejecutar un contenedor Node temporal en `tass-network` y realizar `fetch('http://backend:3000/health')`. Si devuelve 200, el backend responde y el ping de Mongo funciona. Si devuelve 503, la ruta está viva pero indica que Mongo no está disponible. Si no resuelve `backend`, la prueba apunta a red o nombre de servicio, no necesariamente a Mongo.

### f) Errores comunes
Un comando que termina con código 0 solo demuestra lo que su prueba verifica. Un ping HTTP a `/health` no demuestra que el PDF se genere ni que el correo se entregue. Si el contenedor temporal no comparte red, el resultado no es una prueba válida de la conectividad interna. También es importante limpiar el contenedor temporal al terminar.

### g) Conexiones
Se relaciona con `health.routes.ts`, `Dockerfile`, `compose.yml`, DNS interno, redes y diagnóstico de incidentes.

**Autoevaluación:** Si el contenedor temporal no puede resolver `backend`, ¿qué revisarías antes de culpar a MongoDB?

---

## 21. Winston: propósito e importancia

### a) Qué es
Winston es una biblioteca de Node.js para producir registros de eventos de una aplicación de forma estructurada y configurable.

### b) Para qué sirve
Ayuda a investigar fallos, conocer secuencias de ejecución, medir comportamiento operativo y encontrar patrones. En TASS, donde una solicitud puede depender de MongoDB, Redis, RabbitMQ, SMTP y consumidores, los logs ayudan a identificar en qué etapa falló el flujo.

### c) Cómo funciona
Cada registro tiene un nivel (`info`, `error`, etc.), un mensaje o evento y metadatos. Los transports determinan destinos. El formato JSON hace que herramientas puedan filtrar campos de forma más fiable que frases de texto libre. La rotación evita que un único archivo crezca indefinidamente.

### d) Cómo se usa en TASS
Los eventos `database.connected`, `rabbitmq.message.published`, `cache.hit`, `conflict.detection.failed` y `health.mongo.ping_failed` ofrecen señales de diferentes partes del sistema. La política actual evita incluir claves o valores de caché en los eventos `hit/miss`, lo cual reduce exposición de datos.

### e) Ejemplo aplicado a TASS
Si el usuario solicita un Excel y la petición expira, los eventos de publicación, recepción del mensaje, generación y error del consumer ayudan a encontrar si la falla ocurrió antes de publicar, al procesar el mensaje o al devolver la respuesta RPC.

### f) Errores comunes
No considerar los logs como auditoría de negocio completa: un log técnico registra eventos del software, mientras que una auditoría de negocio debe registrar quién cambió qué, cuándo y por qué, con integridad y política de retención. Tampoco almacenar secretos o tokens completos en logs.

### g) Conexiones
Se conecta con catálogo de errores, healthchecks, consumers, seguridad, Docker y monitoreo.

**Autoevaluación:** ¿Por qué Winston no sustituye por sí solo un registro de auditoría de quién resolvió un conflicto?

---

## 22. Qué significa acceder por DNS interno de Compose

### a) Qué es
DNS interno es el mecanismo por el que Docker permite que los servicios de una misma red se encuentren usando sus nombres, por ejemplo `backend`, `mongodb`, `redis` o `rabbitmq`.

### b) Para qué sirve
Evita fijar direcciones IP de contenedores, que pueden cambiar cuando se recrean. Los servicios se conectan por nombre y puerto dentro de la red.

### c) Cómo funciona
Compose crea una red bridge. Cada servicio conectado obtiene resolución de nombres dentro de esa red. Así, Nginx puede hacer proxy a `http://backend:3000`, el backend conectar a `mongodb:27017`, Redis a `redis:6379` y RabbitMQ a `rabbitmq:5672`. Desde Windows, el nombre `backend` normalmente no existe en el DNS del sistema anfitrión; para acceso externo se usa un puerto publicado o un proxy accesible desde el host.

### d) Cómo se usa en TASS
La red `tass-network` está declarada en `compose.yml`. El servicio `frontend` comparte esa red con `backend`, y `nginx.conf` usa `proxy_pass http://backend:3000`. Redis y RabbitMQ no publican sus puertos al host en el Compose revisado; el backend los alcanza por sus nombres internos.

### e) Ejemplo aplicado a TASS
Si el contenedor de backend cambia de IP al reconstruirse, `http://backend:3000` sigue siendo el destino lógico porque Docker actualiza la resolución del servicio. Si el código usa `localhost:6379` desde el backend, intentará conectar a Redis dentro del propio contenedor backend y fallará; debe usar `redis:6379`.

### f) Errores comunes
`localhost` significa “este mismo contenedor” cuando se ejecuta dentro de un contenedor. `expose` no hace que el nombre de servicio se resuelva fuera de la red. Si dos servicios no comparten red, no deben asumir que se pueden resolver por nombre.

### g) Conexiones
Se relaciona con Compose, Nginx, `REDIS_URL`, `RABBITMQ_URL`, `MONGO_URI` y healthchecks.

**Autoevaluación:** ¿Por qué `http://backend:3000` es correcto en Nginx dentro de Compose, pero no es normalmente una URL para escribir directamente en el navegador de Windows?

---

## 23. Separar preproducción y pruebas en Docker

### a) Qué es
Separar entornos significa ejecutar instancias aisladas con configuración, credenciales, datos, nombres de red y recursos distintos según el propósito.

### b) Para qué sirve
Las pruebas deben poder fallar, borrar datos y recrearse sin afectar a preproducción ni producción. Preproducción debe parecerse a producción para validar despliegues antes de liberarlos, pero usar credenciales y datos controlados.

### c) Cómo funciona
Puede hacerse con archivos Compose diferentes, archivos de variables separados, nombres de proyecto distintos o perfiles. Un Dockerfile común puede recibir argumentos de build, pero los datos y secretos del runtime deben configurarse aparte. Un ejemplo conceptual sería `compose.test.yml` con Mongo de pruebas y `compose.preprod.yml` con sus propios nombres de servicio/volúmenes. Las imágenes pueden compartir la misma etiqueta de versión si se promueve el mismo artefacto, mientras la configuración cambia por entorno.

### d) Cómo se usa en TASS
El repositorio tiene `.env.dev`, `.env.local`, `.env.production` y el Compose usa `.env.dev` como `env_file`; el Dockerfile frontend recibe `FRONTEND_ENV`. Los nombres de entorno disponibles en los scripts y la configuración deben alinearse: si se ejecuta `NODE_ENV=staging`, el backend busca `.env.staging`, que debe existir si se depende de ese mecanismo.

### e) Ejemplo aplicado a TASS
Pruebas pueden usar una base `tass_test`, un broker y colas aislados y correo de sandbox. Preproducción puede usar `tass_preprod` y un servidor SMTP de pruebas. Producción usa credenciales guardadas en el sistema de despliegue, no en el repositorio. Cada entorno debe tener su propio volumen para que los datos de pruebas no se mezclen con los reales.

### f) Errores comunes
Cambiar solo `NODE_ENV` no separa la base de datos. Reutilizar el mismo volumen entre pruebas y preproducción puede contaminar los datos. Los secretos no deben quedar versionados. Los argumentos de build frontend no son un lugar para contraseñas. También hay que evitar usar `localhost` como URL API en un bundle que se ejecutará en otro entorno.

### g) Conexiones
Se relaciona con `.env.*`, Compose, Dockerfiles, `env.ts`, configuración Angular, volúmenes, redes y CI/CD.

**Autoevaluación:** ¿Qué tres cosas separarías como mínimo entre pruebas y preproducción para evitar que una prueba afecte a datos reales?

---

## 24. Vite, Alpine y SSR

### a) Qué es
**Vite** es una herramienta de desarrollo y construcción web; **Alpine** es una familia de imágenes Linux de contenedor pequeña; **SSR** significa Server-Side Rendering, renderizado del HTML en el servidor.

### b) Para qué sirve
Vite acelera el ciclo de desarrollo de herramientas web compatibles. Alpine permite crear imágenes de contenedor más pequeñas. SSR puede entregar HTML inicial ya renderizado desde un servidor, en vez de esperar a que el navegador ejecute toda la aplicación.

### c) Cómo funciona
Vite sirve módulos durante desarrollo y optimiza recursos para producción. Angular 21 usa herramientas modernas de build y puede emplear Vite internamente en el servidor de desarrollo; ver carpetas `.angular/cache/.../vite` no significa que el runtime final sea un servidor Vite. Alpine es una distribución Linux basada en musl y BusyBox, popular en imágenes `node:22-alpine` y `nginx:alpine`. SSR ejecuta parte de la aplicación Angular en Node para generar HTML; después el navegador puede hidratarlo y volverlo interactivo.

### d) Cómo se usa en TASS
El Dockerfile frontend compila Angular en `node:22-alpine` y usa `nginx:alpine` para servir el contenido de `dist/.../browser`. El proyecto tiene `@angular/ssr`, `src/server.ts`, `src/main.server.ts` y configuraciones server-side. Sin embargo, el Dockerfile de runtime copiado sirve el directorio `browser` mediante Nginx estático; no ejecuta el servidor SSR Node en producción dentro de esa imagen. La presencia de archivos SSR en el proyecto no prueba que SSR esté activo en el despliegue actual.

### e) Ejemplo aplicado a TASS
Durante desarrollo, Angular puede usar Vite en el proceso de build/servidor. En la imagen final, Nginx entrega `index.html`, JavaScript y CSS. Si se quisiera servir SSR real, el despliegue necesitaría ejecutar el servidor Node generado para SSR y configurar el proxy/hosting de forma correspondiente, no solo copiar los archivos `browser` a Nginx.

### f) Errores comunes
Vite no es un framework de backend. Alpine no es una herramienta de Angular; es el sistema base de la imagen. SSR no significa simplemente “tener una carpeta server”. Además, imágenes Alpine pequeñas pueden requerir atención a compatibilidad de dependencias nativas.

### g) Conexiones
Se relaciona con Angular CLI, `package.json`, `Dockerfile`, `nginx.conf`, Node y el renderizado del navegador.

**Autoevaluación:** ¿Por qué encontrar `@angular/ssr` en `package.json` no demuestra que el contenedor final esté ejecutando SSR?

---

## 25. Por qué Node construye y Nginx sirve el frontend SPA

### a) Qué es
Una SPA (Single Page Application) es una aplicación web que carga una página base y cambia de vista en el navegador mediante JavaScript, sin pedir al servidor un HTML nuevo para cada ruta interna. Node puede compilar el frontend; Nginx puede servir los archivos ya compilados.

### b) Para qué sirve
Separar construcción y ejecución permite que la imagen final del frontend no cargue Node, Angular CLI ni dependencias de desarrollo. Nginx es eficiente para entregar archivos estáticos y hacer proxy HTTP al backend.

### c) Cómo funciona
La primera etapa del Dockerfile usa `node:22-alpine`, instala dependencias con `npm ci`, copia el proyecto y ejecuta `ng build`. La segunda etapa parte de `nginx:alpine` y copia solo `dist/trabajoTASSfrontend/browser/` a `/usr/share/nginx/html/`. Nginx entrega esos archivos. La regla `try_files $uri $uri/ /index.html` hace que una ruta como `/admin/conflicts` devuelva `index.html`, para que Angular Router resuelva esa ruta en el navegador.

### d) Cómo se usa en TASS
El archivo `frontend/Dockerfile` implementa exactamente el patrón multi-stage build. Nginx también reenvía `/api/` al backend. Esto significa que el contenedor frontend final es un servidor web estático con proxy, no el servidor de desarrollo Angular.

### e) Ejemplo aplicado a TASS
El usuario entra a `http://localhost:11001/admin/conflicts`. Nginx no encuentra necesariamente un archivo físico `/admin/conflicts`, por lo que devuelve `index.html`; Angular lee la ruta y muestra la tabla. Cuando la tabla consulta `/api/conflicts`, Nginx envía esa solicitud al servicio `backend:3000`.

### f) Errores comunes
Si se omite el fallback a `index.html`, recargar una ruta Angular puede devolver 404. No se debe usar `ng serve` como servidor de producción por defecto. Copiar el directorio equivocado —por ejemplo, el directorio padre en vez de `browser`— puede causar una página vacía. Las variables de API compiladas en el frontend no cambian mágicamente después del build.

### g) Conexiones
Se conecta con `Dockerfile`, `nginx.conf`, Angular Router, rutas API, Compose y la separación de entornos.

**Autoevaluación:** ¿Qué hace Nginx cuando el navegador pide directamente `/admin/conflicts` y no existe un archivo físico con ese nombre?

---

## 26. Healthcheck: definición, límites y estados

### a) Qué es
Un healthcheck es una prueba repetida que determina si un contenedor parece capaz de cumplir una condición de salud definida.

### b) Para qué sirve
Permite que Docker distinga entre un proceso ejecutándose y un servicio que responde correctamente a una prueba. Compose puede esperar a que una dependencia esté saludable antes de iniciar otra.

### c) Cómo funciona
En el Compose de TASS, Mongo usa `mongosh` para hacer `ping` con autenticación; Redis usa `redis-cli ping`; RabbitMQ usa `rabbitmq-diagnostics check_running`; backend consulta `/health`; frontend solicita `/`. Docker repite la prueba según `interval`, limita el tiempo con `timeout`, permite una ventana inicial con `start_period` y marca el servicio como no saludable después de los `retries` fallidos.

### d) Cómo se usa en TASS
El backend depende de Mongo con `condition: service_healthy`. El frontend depende de que el backend esté saludable. Esto reduce el riesgo de iniciar el siguiente servicio demasiado pronto, aunque la aplicación todavía debe gestionar desconexiones que ocurran después del arranque.

### e) Ejemplo aplicado a TASS
Si Redis está iniciado pero no responde a `PING`, su healthcheck falla. El backend podría seguir iniciado porque el Compose actual no declara una dependencia `service_healthy` de Redis, aunque `server.ts` llama a `connectRedis()` al arrancar. El resultado puede ser que el proceso no arranque si esa conexión lanza error; debe comprobarse con logs.

### f) Errores comunes
Un healthcheck no reinicia automáticamente toda arquitectura de forma inteligente ni comprueba cada función. `healthy` significa que la prueba definida pasa, no que el negocio esté libre de errores. Si la ruta `/health` solo prueba Mongo, no detecta SMTP roto ni colas bloqueadas.

### g) Conexiones
Se conecta con `health.routes.ts`, Dockerfile, Compose, `depends_on`, DNS y observabilidad.

**Autoevaluación:** ¿Qué significa realmente que el contenedor backend aparezca `healthy` si `/health` solo prueba MongoDB?

---

## 27. Cómo Nginx encuentra el backend

### a) Qué es
Es la resolución del nombre de servicio `backend` por la red de Docker y el uso de Nginx como proxy inverso para reenviar solicitudes API.

### b) Para qué sirve
El navegador puede llamar al mismo origen que sirve el frontend (`/api/...`), mientras Nginx se comunica internamente con el backend. Esto simplifica las URLs del navegador y evita depender de que el navegador resuelva nombres privados de Docker.

### c) Cómo funciona
En `frontend/nginx.conf`, el bloque `location /api/` contiene `proxy_pass http://backend:3000;`. Docker resuelve `backend` a la IP actual del contenedor que presta ese servicio. Nginx reenvía la solicitud y añade cabeceras como `Host`, `X-Real-IP`, `X-Forwarded-For` y `X-Forwarded-Proto`. La ruta restante se conserva con esta forma de `proxy_pass` sin una URI final añadida.

### d) Cómo se usa en TASS
El servicio frontend y backend comparten `tass-network`. El puerto 3000 no necesita ser llamado directamente por el navegador cuando se usa el proxy; el usuario accede al frontend en el puerto 11001 y solicita rutas `/api/...`.

### e) Ejemplo aplicado a TASS
Angular solicita `GET /api/conflicts`. El navegador envía la petición al host del frontend. Nginx reconoce el prefijo `/api/`, la reenvía a `backend:3000`, Express recibe la ruta API y ejecuta el controlador. La respuesta vuelve por Nginx al navegador.

### f) Errores comunes
Si Nginx no comparte red con backend, no podrá resolver el nombre. Si el backend escucha solo en `127.0.0.1`, otros contenedores no podrán conectarse; en `server.ts`, el servidor escucha en `0.0.0.0`. No se debe confundir la dirección interna `backend:3000` con la dirección pública que usa el navegador.

### g) Conexiones
Se conecta con `nginx.conf`, `compose.yml`, DNS de Docker, `server.ts`, CORS y servicios Angular.

**Autoevaluación:** Describe el recorrido de una petición `GET /api/conflicts` desde Angular hasta Express y de vuelta.

---

## 28. Catálogo de errores errorCatalog.ts

### a) Qué es
`backend/src/utils/errorCatalog.ts` es un catálogo central de códigos, estados HTTP, descripciones y módulos para los errores conocidos de TASS.

### b) Para qué sirve
Evita que cada módulo invente nombres distintos para el mismo problema y facilita relacionar logs, respuestas y documentación de errores.

### c) Cómo funciona
Define el tipo `ErrorCatalogModule`, que limita los módulos válidos, y `ErrorCatalogEntry`, que describe los campos `codigo`, `httpStatus`, `descripcion` y `modulo`. El objeto `ErrorCatalog` incluye entradas como T400, T401, T409, T500, T502 y T503. `as const satisfies Record<string, ErrorCatalogEntry>` conserva los valores literales y verifica que las entradas tengan la forma esperada. `ErrorCode` se deriva de las claves del objeto.

### d) Cómo se usa en TASS
`redis.ts` usa T502 al registrar fallos de Redis; `rabbitmq.ts` y el productor/consumidor usan T503 en errores de RabbitMQ. El documento `backend/docs/error-catalog.md` explica los códigos. Sin embargo, el catálogo no se aplica automáticamente a todas las respuestas HTTP: cada controlador o middleware debe integrarlo explícitamente.

### e) Ejemplo aplicado a TASS
Cuando falla la conexión de Redis, el logger registra `codigo: ErrorCatalog.T502.codigo` y `mensaje: ErrorCatalog.T502.descripcion`. Eso da consistencia al log. No significa necesariamente que el navegador reciba un HTTP 502, porque ese fragmento es un log de evento; el estado HTTP depende de la ruta y del middleware que maneje el error.

### f) Errores comunes
Un código interno T502 no tiene que coincidir siempre con un estado HTTP si el diseño no lo implementa así. El documento del catálogo advierte que algunos estados asociados tienen significados HTTP estándar diferentes a la descripción interna. Además, los códigos T501, T505, T507 o T508 deben revisarse en contexto antes de asumir que todas las rutas ya los devuelven.

### g) Conexiones
Se conecta con `errors.ts`, middleware de errores, Winston, Redis, RabbitMQ, validadores y documentación.

**Autoevaluación:** ¿Qué diferencia existe entre registrar el código T502 en un log y responder realmente una petición HTTP con estado 502?

---

## 29. Qué hace Nginx en el frontend

### a) Qué es
Nginx es un servidor web que en TASS entrega los archivos estáticos de Angular y actúa como proxy inverso para las rutas API.

### b) Para qué sirve
Evita ejecutar un servidor de desarrollo en producción, sirve archivos estáticos de manera eficiente y permite que frontend y backend se presenten bajo un mismo origen web.

### c) Cómo funciona
`root /usr/share/nginx/html` define dónde están los archivos. `index index.html` establece el archivo inicial. `location /api/` reenvía solicitudes al backend. `location /` intenta encontrar el recurso y, si no existe, devuelve `/index.html`, necesario para rutas de SPA. `listen 80` recibe tráfico HTTP dentro del contenedor.

### d) Cómo se usa en TASS
El Dockerfile copia el bundle Angular al directorio raíz de Nginx y copia `nginx.conf` como configuración del sitio. Compose publica el puerto 80 del contenedor al puerto del host, por defecto 11001.

### e) Ejemplo aplicado a TASS
Al abrir TASS, Nginx devuelve HTML, CSS y JavaScript. Angular renderiza la vista. Al consultar los conflictos, Nginx reenvía `/api/...` a Express. El navegador no necesita conocer el DNS interno de Docker.

### f) Errores comunes
Nginx no ejecuta la lógica TypeScript del backend ni sustituye MongoDB. Tampoco autentica por sí solo a los usuarios; la autorización sigue siendo responsabilidad de la aplicación. La configuración del proxy debe coincidir con las rutas montadas en Express.

### g) Conexiones
Se conecta con SPA, Docker multi-stage, rutas Angular, Express, Compose y cabeceras HTTP.

**Autoevaluación:** ¿Cuáles son las dos responsabilidades concretas de Nginx en la configuración de TASS?

---

## 30. Redis, RabbitMQ y redis.ts

### a) Qué es
Redis es un almacén de datos en memoria usado aquí para caché temporal y control de sesiones/intentos; RabbitMQ es un broker de mensajes que distribuye trabajos entre productores y consumidores. Resuelven problemas distintos.

### b) Para qué sirve
Redis evita repetir consultas o permite controlar estados temporales con expiración. RabbitMQ desacopla tareas que pueden procesarse fuera de la petición HTTP, como correos, detecciones programadas o generación de reportes.

### c) Cómo funciona
En `backend/src/config/redis.ts`, `createClient()` crea un cliente Redis con `process.env.REDIS_URL` o `redis://redis:6379`. Se registran eventos `connect` y `error`; los errores se loguean con el código T502. `connectRedis()` abre la conexión si `isOpen` es falso y `closeRedis()` la cierra durante el apagado. Redis no reemplaza MongoDB: la documentación indica que Mongo sigue siendo la fuente de verdad y que la caché puede perderse.

RabbitMQ usa `amqplib`, conexiones y canales. Un productor publica mensajes en colas; un consumer los recibe, ejecuta un handler y confirma (`ack`) o rechaza (`nack`) el mensaje. La configuración se encuentra en `rabbitmq.ts`, `messageProducer.ts` y `messageConsumer.ts`.

### d) Cómo se usa en TASS
Redis almacena caché de sesiones/listados/estadísticas y límites de intentos de login. RabbitMQ se usa para correo de verificación, detección programada y reportes RPC. En `server.ts`, ambas conexiones se abren durante el arranque y se cierran durante el apagado controlado.

### e) Ejemplo aplicado a TASS
Si el dashboard consulta repetidamente las estadísticas, Redis puede devolver el resultado guardado durante el TTL. Si se registra un usuario, RabbitMQ permite que un consumer procese el envío del correo aparte de la respuesta inicial del endpoint. Si Redis cae, la caché puede fallar; si RabbitMQ cae, los trabajos encolados y reportes pueden no ejecutarse.

### f) Errores comunes
Redis no debe ser el único lugar donde exista un conflicto permanente. RabbitMQ no es una base de datos de negocio. Un mensaje publicado no significa que la tarea terminó. El puerto Redis no se publica al host en el Compose revisado, y se recomienda no exponerlo a redes no confiables.

### g) Conexiones
Se conecta con caché, sesiones, auth, correo, detección, RPC, logs, healthchecks y apagado graceful.

**Autoevaluación:** Si desaparece toda la información de Redis, ¿qué datos debería poder reconstruir TASS desde MongoDB y qué tipo de trabajo depende de RabbitMQ?

---

## 31. cacheService.ts

### a) Qué es
`backend/src/services/cacheService.ts` es una capa pequeña que envuelve las operaciones comunes de Redis para que el resto del backend use una interfaz uniforme.

### b) Para qué sirve
Evita repetir serialización JSON, validación de expiración y registro de aciertos/fallos en cada controlador o servicio.

### c) Cómo funciona
`readTtl(name, fallback)` obtiene un valor de entorno, lo convierte a número y exige un entero positivo seguro. `CACHE_TTL` define segundos predeterminados: sesión 3600, empleados 600, conflictos 300 y notificaciones 60. `get<T>(key)` lee la cadena de Redis; si no existe, registra `cache.miss` y devuelve `null`; si existe, registra `cache.hit` y convierte JSON al tipo solicitado. `set<T>` valida el TTL, serializa el valor y lo almacena con expiración. Las funciones `del`, `exists` y otras utilidades del archivo encapsulan eliminación y comprobación de existencia. Los logs no incluyen claves ni valores.

### d) Cómo se usa en TASS
La autenticación utiliza claves para sesión/revocación e intentos de login. Los servicios de empleados, conflictos y notificaciones cachean consultas o contadores. El TTL determina cuánto tiempo puede reutilizarse el resultado antes de que Redis lo expire.

### e) Ejemplo aplicado a TASS
El dashboard solicita `conflicts:dashboard`. Si la clave está presente, el servicio devuelve las estadísticas guardadas; si no, consulta MongoDB, calcula los indicadores, guarda el resultado con `CACHE_TTL.conflicts` y responde. Como el TTL es 300 segundos por defecto, el resultado puede permanecer hasta cinco minutos si no se invalida manualmente.

### f) Errores comunes
Una caché puede quedar desactualizada si cambia MongoDB y no se borra la clave. El TTL no es garantía de exactitud inmediata, sino un límite temporal para reutilizar datos. `JSON.parse` puede fallar si el contenido guardado está corrupto o tiene un formato inesperado. La disponibilidad de Redis también debe contemplarse en las operaciones que lo necesitan.

### g) Conexiones
Se conecta con `redis.ts`, variables de entorno, dashboard, auth, listados y eventos Winston `cache.hit`/`cache.miss`.

**Autoevaluación:** ¿Qué significa un `cache.miss`, y por qué una escritura nueva en MongoDB no actualiza automáticamente todas las claves Redis?

---

## 32. Interpretar el mensaje de Copilot sobre Redis y Compose

### a) Qué es
Es una descripción de cambios propuestos/aplicados a la infraestructura, configuración de caché y verificación del proyecto. Hay que traducir cada frase a lo que hace el código y distinguir verificación estática de prueba real.

### b) Para qué sirve
Entender un resumen de IA exige saber qué se cambió, qué se comprobó, qué quedó pendiente y qué limitaciones de alcance se aceptaron.

### c) Cómo funciona
“Creados `src/config/redis.ts` y `src/services/cacheService.ts`” significa que hay un cliente Redis y una capa de caché. “Usa `REDIS_URL` o `redis://redis:6379`” indica que se puede sobrescribir la dirección; el valor por defecto corresponde al DNS interno de Compose. “Registra connect/error con T502” describe los eventos de log. “Cierre graceful” significa que el servidor intenta cerrar conexiones al apagarse, en vez de terminar dejando recursos abiertos.

“TTL defaults 3600/600/300/60” significa segundos: 1 hora para sesión, 10 minutos para empleados, 5 minutos para conflictos y 1 minuto para notificaciones. “Hit/miss sin registrar claves/datos” describe una medida de privacidad en logs. “`npm run build` y `git diff --check` pasaron” comprueba compilación y problemas de whitespace/diff, no demuestra que todos los flujos funcionen en ejecución. `docker compose ... config -q` valida que Compose pueda interpretar la configuración con las variables disponibles. Que falle sin `.env` indica que hay variables obligatorias que no están definidas para ese comando. “No ejecuté prueba de conexión real Redis” declara explícitamente una prueba pendiente en ese momento.

### d) Cómo se usa en TASS
El código actual confirma la existencia de `redis.ts`, `cacheService.ts` y las variables de TTL en Compose. El documento `docs/redis-usage.md` registra además pruebas de smoke anteriores, pero hay que diferenciar esa documentación de una prueba ejecutada durante el cambio de Copilot descrito. Los valores de `.env` no deben copiarse a documentación ni logs.

### e) Ejemplo aplicado a TASS
Si `docker compose config -q` pasa con `--env-file .env.dev`, se sabe que Compose puede resolver la configuración para ese archivo. No se sabe todavía si Redis acepta la conexión del backend en ese arranque. Para demostrarlo hay que levantar servicios, revisar estado y logs y ejecutar una operación real de `PING` o lectura/escritura.

### f) Errores comunes
“Compila” no significa “está probado end-to-end”. “No publicó un puerto” debe verificarse contra el `compose.yml` exacto y el commit concreto. En el ZIP revisado, Redis no tiene `ports`, pero Mongo sí tiene `27017:27017`; por tanto, la afirmación de que Mongo no está publicado no corresponde a esta copia actual. Las URLs `FRONTEND_URL` y `BASE_URL` fijadas a localhost pueden ser adecuadas para local, pero requieren revisión al desplegar fuera de la máquina local.

### g) Conexiones
Se conecta con Redis, Compose, archivos `.env`, pruebas build/config, seguridad de secretos, Mongo y despliegue.

**Autoevaluación:** ¿Qué diferencia hay entre una compilación correcta, una configuración Compose válida y una prueba real de conexión a Redis?

---

## 33. rabbitmq.ts

### a) Qué es
`backend/src/config/rabbitmq.ts` es el módulo que establece, reutiliza y cierra la conexión principal del backend con RabbitMQ.

### b) Para qué sirve
Evita abrir conexiones duplicadas innecesarias y centraliza el manejo de errores y cierre de la conexión.

### c) Cómo funciona
El archivo mantiene `rabbitConnection` y `connectionPromise`. `connectRabbitMQ()` devuelve la conexión existente si ya hay una; si no, crea una promesa compartida para que llamadas concurrentes esperen la misma conexión. `openConnection()` lee `RABBITMQ_URL`; si falta, lanza error. Luego usa `connect(url)` de `amqplib`, registra eventos `error` y `close`, guarda la conexión y emite `rabbitmq.connected`. Si falla, registra `rabbitmq.connection.failed` con T503 y vuelve a lanzar el error. `closeRabbitMQ()` borra la referencia y cierra la conexión si existía.

### d) Cómo se usa en TASS
`messageProducer.ts` y `messageConsumer.ts` llaman a `connectRabbitMQ()` y crean sus propios canales. `server.ts` conecta RabbitMQ durante el arranque y llama a `closeRabbitMQ()` durante el apagado controlado. `rabbitmq.ts` no define las colas ni decide qué hacer con cada mensaje; esa responsabilidad está en los módulos productor/consumidor y en la configuración del broker.

### e) Ejemplo aplicado a TASS
Cuando se necesita publicar el correo de verificación, el productor pide la conexión compartida. Si ya existe, la reutiliza; si aún se está estableciendo, espera la promesa existente. Después crea o reutiliza su canal confirmable y publica en la cola correspondiente.

### f) Errores comunes
Una conexión no es lo mismo que un canal: la conexión es la sesión con el broker; los canales son vías lógicas para operar dentro de ella. El evento `close` borra la referencia local, pero el código no implementa por sí solo una estrategia completa de reconexión automática tras cualquier cierre. También debe garantizarse que la URL contenga credenciales y vhost correctos.

### g) Conexiones
Se relaciona con `RABBITMQ_URL`, `messageProducer.ts`, `messageConsumer.ts`, `definitions.json`, catálogo T503 y cierre graceful.

**Autoevaluación:** ¿Qué diferencia hay entre la conexión compartida que mantiene `rabbitmq.ts` y los canales que crean productor y consumidor?

---

## 34. vhost, broker, consumer y colas

### a) Qué es
Un **broker** es el servidor RabbitMQ que recibe y distribuye mensajes. Una **cola** guarda mensajes hasta que un consumidor los procesa. Un **consumer** es el proceso que recibe y ejecuta el trabajo. Un **vhost** (virtual host) es un espacio lógico aislado dentro de RabbitMQ que agrupa colas, exchanges y permisos.

### b) Para qué sirve
Estos elementos permiten que el código que solicita una tarea no tenga que ejecutarla necesariamente dentro de la misma petición. El vhost separa recursos y permisos; las colas separan tipos de trabajo; los consumers ejecutan el trabajo cuando están disponibles.

### c) Cómo funciona
El productor publica un mensaje a una cola. RabbitMQ lo mantiene según la configuración y entrega el mensaje a un consumer. El consumer procesa el contenido y confirma con `ack`; si falla, puede rechazarlo con `nack` y pedir reencolado o enviarlo a una dead-letter queue según la configuración. Un mensaje persistente y una cola durable mejoran la resistencia a reinicios, aunque la durabilidad completa depende de la configuración de cola, mensaje, confirmaciones y almacenamiento.

### d) Cómo se usa en TASS
`messageProducer.ts` define `tass.conflict.detection`, `tass.email.notification` y `tass.report.generation`. `messageConsumer.ts` registra handlers para esas colas. El broker es el servicio `rabbitmq` en Compose. `RABBITMQ_URL` especifica cómo conectarse, incluyendo host, puerto, usuario, contraseña y a menudo el vhost.

### e) Ejemplo aplicado a TASS
El registro encola un mensaje para `tass.email.notification`. El consumer lo recibe y envía el correo. El controlador no necesita mantener una conexión SMTP mientras crea el usuario. Para un reporte, el mensaje incluye el formato y metadatos RPC; el consumer genera el archivo y lo devuelve al solicitante.

### f) Errores comunes
La cola no ejecuta código por sí misma: el consumer contiene el handler. El broker no es la base de datos de usuarios. Una cola vacía no demuestra que la función nunca se ejecutó; quizá los mensajes se procesaron. Un vhost no es un contenedor ni una dirección IP: es un límite lógico dentro de RabbitMQ.

### g) Conexiones
Se conecta con `rabbitmq.ts`, `messageProducer.ts`, `messageConsumer.ts`, `definitions.json`, `RABBITMQ_URL`, DLQ y reportes RPC.

**Autoevaluación:** Si existe una cola pero no hay ningún consumer activo para ella, ¿qué ocurre con los mensajes y por qué?

---

## 35. definitions.json y RABBITMQ_URL

### a) Qué es
`docker/rabbitmq/definitions.json` declara recursos de RabbitMQ —por ejemplo usuarios, permisos, vhosts, exchanges, colas y bindings— para inicializar el broker de forma repetible. `RABBITMQ_URL` es la URL que usa el backend para conectarse al broker.

### b) Para qué sirve
Las definiciones evitan crear manualmente la misma estructura cada vez que se despliega. La URL permite al backend encontrar el broker y autenticarse en el vhost correcto.

### c) Cómo funciona
RabbitMQ puede cargar definiciones al iniciar, según la configuración y el mecanismo preparado en `docker/rabbitmq/`. La URL suele tener una forma similar a `amqp://usuario:contraseña@rabbitmq:5672/vhost`; caracteres especiales de usuario/contraseña deben codificarse correctamente. El vhost `/` tiene una representación especial en URLs, por lo que la codificación importa. El valor exacto debe tomarse del `.env.dev` o del archivo de ejemplo sin divulgar credenciales.

### d) Cómo se usa en TASS
El backend lee `process.env.RABBITMQ_URL` dentro de `rabbitmq.ts`. Compose exige esa variable con `${RABBITMQ_URL:?Define RABBITMQ_URL}`. El servicio RabbitMQ recibe variables para credenciales de administrador y backend. La definición y el script de entrada determinan cómo se preparan recursos y permisos. El nombre de servicio `rabbitmq` es el host interno correcto en la red Compose.

### e) Ejemplo aplicado a TASS
En desarrollo, la URL debe apuntar a `rabbitmq:5672`, no a `localhost:5672`, porque backend y broker son contenedores separados. Si la URL usa un vhost en el que no existen las colas o el usuario no tiene permisos, la conexión o la publicación puede fallar aunque el contenedor RabbitMQ aparezca saludable.

### f) Errores comunes
No confundir `definitions.json` con el archivo de variables secretas. No compartir el valor de `RABBITMQ_URL` si contiene contraseña. Un healthcheck `check_running` puede pasar aunque el backend use credenciales incorrectas. Cambiar definiciones puede no modificar recursos existentes en un volumen persistente de la forma esperada; el comportamiento depende de cómo RabbitMQ carga definiciones y de la persistencia actual.

### g) Conexiones
Se relaciona con Compose, `rabbitmq.conf`, `tass-entrypoint.sh`, `rabbitmq.ts`, usuarios, permisos, colas y vhosts.

**Autoevaluación:** ¿Qué puede estar mal si RabbitMQ está saludable pero el backend no logra publicar en `tass.email.notification`?

---

## 36. Reportes con RabbitMQ, SSE, auditoría, push, smoke test, DLQ y SMTP

### a) Qué es
Este apartado reúne términos que aparecen juntos en la arquitectura asíncrona. **RPC** es una petición de trabajo remoto con respuesta correlacionada; **SSE** es Server-Sent Events, una conexión HTTP por la que el servidor transmite eventos al navegador; **auditoría** es el registro de acciones de negocio; **push** es la entrega proactiva de una notificación; **smoke test** es una prueba rápida de que una ruta crítica funciona; **DLQ** es una cola de mensajes fallidos; **SMTP** es el protocolo usado para enviar correo.

### b) Para qué sirve
RPC permite que HTTP solicite un PDF/Excel a un consumer y espere el resultado. SSE puede avisar al frontend de cambios sin que tenga que consultar continuamente. La auditoría responde quién hizo qué y cuándo. Push entrega una actualización proactiva. Smoke tests detectan fallos básicos tras un despliegue. DLQ conserva mensajes que agotaron sus intentos. SMTP conecta TASS con el servicio que entrega el correo.

### c) Cómo funciona
En los reportes, `report-rpc.service.ts` envía un mensaje con `correlationId` y `replyTo`; el consumer genera el archivo y publica bytes en la dirección de respuesta con el mismo identificador. El servicio RPC espera el mensaje coincidente y lo devuelve al controlador, que responde como descarga. No es “fire-and-forget”: el HTTP espera la respuesta.

SSE mantiene una respuesta HTTP abierta con `Content-Type: text/event-stream`; el servidor escribe eventos a medida que ocurren. El archivo `notification-stream.service.ts` gestiona streams y `notification.controller.ts`/rutas relacionan las notificaciones. SSE es unidireccional: servidor a navegador. Para acciones del navegador al servidor se usa HTTP normal. “Push” no implica necesariamente Web Push del navegador; en TASS puede referirse a empujar eventos por SSE. La auditoría de negocio no debe confundirse con Winston: Winston registra eventos técnicos; una auditoría debería guardar usuario, acción, entidad, fecha y, cuando proceda, estado anterior/nuevo en un almacenamiento apropiado.

El consumer procesa mensajes con `ack` cuando el handler termina. Si falla, el código permite un reintento de la entrega inicial; si el mensaje ya venía redelivered y vuelve a fallar, lo rechaza sin reencolar, lo que puede activar la dead-letter configuration. Una DLQ necesita configuración real en la cola o broker; no basta con escribir “dead-letter” en un log. SMTP es el servicio/protocolo de salida para correos, configurado mediante variables de entorno y usado por Nodemailer.

### d) Cómo se usa en TASS
El código de `messageConsumer.ts` registra eventos de recepción, fallo, reencolado y dead-letter. `docs/rabbitmq-usage.md` documenta pruebas de colas y DLQ con mensajes sintéticos, y advierte que las pruebas fueron efímeras. El consumer usa `replyTo` y `correlationId` para responder a reportes. `notification-stream.service.ts` mantiene streams SSE, y el servidor los cierra en apagado. `server.ts` programa una detección diaria a las 16:08, zona `America/Bogota`, que publica en `tass.conflict.detection`.

### e) Ejemplo aplicado a TASS
El administrador pide descargar PDF. El controlador envía una solicitud RPC a `tass.report.generation`, con formato `pdf`. El consumer consulta MongoDB y genera el PDF; devuelve los bytes con el mismo `correlationId`; el HTTP responde `application/pdf` y nombre de descarga. En otro flujo, el cron encola una detección programada. El consumer procesa la tarea y crea notificaciones. Si el navegador tiene un SSE abierto, el servidor puede emitir eventos de notificación para que la interfaz actualice su indicador sin sondear constantemente. Para verificar despliegue, un smoke test podría comprobar `/health`, login de prueba controlado y una operación de lectura; no debería enviar correos reales ni usar datos personales sin autorización.

### f) Errores comunes
No llamar “asíncrono sin espera” a un reporte RPC que el HTTP espera. No asumir que SSE es lo mismo que WebSocket: SSE es principalmente servidor→cliente y usa HTTP. No asumir que “push” significa siempre notificación nativa del navegador. No confundir log técnico con auditoría legal/de negocio. No reencolar indefinidamente un mensaje venenoso: hacen falta límites y DLQ. Un smoke test no reemplaza pruebas unitarias, integración ni pruebas de carga. SMTP puede aceptar el mensaje y aun así este terminar en spam o rebotar después.

### g) Conexiones
RPC enlaza controlador, `report-rpc.service.ts`, `messageProducer.ts`, `messageConsumer.ts` y servicios PDF/Excel. SSE enlaza notificaciones, el servicio de streams y frontend. Auditoría se relaciona con cambios de estado y usuarios autenticados. DLQ se relaciona con configuración RabbitMQ, reintentos y operación. SMTP se conecta con correo, plantilla EJS y variables de entorno.

**Autoevaluación:** ¿Puedes explicar la diferencia entre un reporte RPC que espera un archivo, una notificación SSE y un mensaje de correo procesado por un consumer?

---

## Glosario consolidado

- **ACK (`ack`)**: confirmación del consumer de que procesó el mensaje.
- **Alpine**: distribución Linux pequeña usada como base de imágenes Docker.
- **API**: interfaz por la que dos partes de software se comunican.
- **Auditoría**: registro de acciones de negocio, responsable y momento.
- **Autenticación**: comprobación de la identidad del usuario.
- **Autorización**: comprobación de qué acciones puede realizar esa identidad.
- **Bearer**: esquema de la cabecera HTTP `Authorization` que transporta un token.
- **Broker**: servidor que recibe y distribuye mensajes; aquí, RabbitMQ.
- **Build**: proceso de construir o compilar el artefacto ejecutable.
- **Cache hit**: lectura cuyo valor estaba en caché.
- **Cache miss**: lectura cuyo valor no estaba en caché.
- **Canal**: vía lógica de operación dentro de una conexión RabbitMQ.
- **Consumer**: proceso que recibe mensajes y ejecuta el trabajo.
- **Contenedor**: instancia aislada que ejecuta una imagen.
- **CORS**: política que controla solicitudes entre distintos orígenes desde navegadores.
- **Cron**: tarea programada para ejecutarse según un calendario.
- **DNS**: sistema que resuelve nombres a direcciones de red.
- **Docker**: plataforma para construir y ejecutar contenedores.
- **Docker Compose**: herramienta para definir y ejecutar servicios relacionados.
- **DLQ / dead-letter queue**: cola que recibe mensajes que no pudieron procesarse normalmente.
- **DTO/payload**: datos enviados entre partes; en JWT, el payload contiene claims.
- **EJS**: motor de plantillas para generar contenido, como HTML de correos.
- **Endpoint**: ruta de API que recibe una solicitud.
- **Entorno**: conjunto de configuración que corresponde a local, pruebas, preproducción o producción.
- **Exchange**: componente RabbitMQ que enruta mensajes hacia colas.
- **Express**: framework Node.js usado para construir el backend HTTP.
- **Healthcheck**: prueba repetida de salud de un servicio.
- **HTTP**: protocolo de comunicación web.
- **Idempotencia**: propiedad por la que repetir una operación no duplica el efecto no deseado.
- **JWT**: formato de token firmado con claims.
- **Middleware**: función intermedia de Express que procesa una solicitud antes de llegar a la ruta o después de un error.
- **MongoDB**: base de datos documental usada como fuente persistente de datos de negocio.
- **Mongoose**: biblioteca para modelar y consultar documentos MongoDB desde Node.js.
- **Nginx**: servidor web y proxy inverso.
- **Node.js**: entorno de ejecución JavaScript fuera del navegador.
- **ObjectId**: identificador habitual de documentos MongoDB.
- **Preproducción**: entorno similar a producción para validar antes del despliegue final.
- **Productor**: código que publica mensajes en RabbitMQ.
- **Proxy inverso**: servidor que recibe una petición y la reenvía a otro servidor.
- **RabbitMQ**: broker de mensajería.
- **Redis**: almacén en memoria utilizado en TASS para datos temporales/cache.
- **RPC**: patrón de solicitud y respuesta para pedir una operación a otro proceso.
- **SMTP**: protocolo para enviar correo electrónico a través de un servidor de correo.
- **SPA**: aplicación de una sola página cuyo enrutamiento ocurre en el navegador.
- **SSE**: mecanismo HTTP de eventos enviados desde servidor a navegador.
- **SSR**: renderizado de HTML en el servidor.
- **TTL**: tiempo de vida antes de expirar un valor de caché.
- **Transport Winston**: destino de un registro, como consola o archivo.
- **Vhost**: espacio lógico aislado dentro de RabbitMQ.
- **Winston**: biblioteca de logging estructurado para Node.js.

---

## Mapa mental de TASS

```mermaid
flowchart TD
    UI[Frontend Angular SPA] -->|/api| NG[Nginx en contenedor frontend]
    NG -->|DNS interno: backend:3000| API[Backend Express / Node]
    API --> AUTH[Autenticación y roles]
    AUTH --> AP[AuthorizedPerson: autorización previa]
    AUTH --> USER[User: cuenta y estado]
    USER -->|verificación| QMAIL[Cola tass.email.notification]
    QMAIL --> CONSUMER[Consumer RabbitMQ]
    CONSUMER --> SMTP[SMTP / Nodemailer]
    API --> MONGO[(MongoDB: fuente de verdad)]
    API --> REDIS[(Redis: caché y sesiones temporales)]
    API --> DET[Servicio de detección de conflictos]
    FAM[Relaciones familiares] --> MONGO
    DET --> MONGO
    DET --> NOTIF[Notificaciones]
    NOTIF --> SSE[SSE: eventos al navegador]
    CRON[Cron diario] --> QDET[Cola tass.conflict.detection]
    QDET --> CONSUMER
    UI -->|solicitud PDF/Excel| API
    API --> QRPC[Cola tass.report.generation / RPC]
    QRPC --> CONSUMER
    CONSUMER --> REPORT[PDFKit / ExcelJS]
    REPORT --> API
    API --> LOG[Winston + ErrorCatalog]
    DOCKER[Docker Compose / red / volúmenes / healthchecks] --- NG
    DOCKER --- API
    DOCKER --- MONGO
    DOCKER --- REDIS
    DOCKER --- CONSUMER
```

### Cómo interpretar el mapa

Angular presenta las vistas y envía peticiones HTTP. Nginx entrega los archivos de la SPA y reenvía `/api` al backend por la red interna. Express valida la petición y delega en controladores y servicios. MongoDB conserva los datos de negocio. Redis conserva información temporal para acelerar lecturas o controlar sesiones; no reemplaza MongoDB. RabbitMQ desacopla tareas: correo, detección programada y reportes RPC. Los consumers ejecutan el trabajo y confirman o rechazan mensajes. Winston registra eventos técnicos; el catálogo asigna códigos internos. Docker Compose conecta los servicios, proporciona variables, conserva volúmenes y ejecuta healthchecks.

### Observaciones de precisión para esta copia del proyecto

1. `backend/src/routes/health.routes.ts` comprueba la conexión y el ping de MongoDB; no comprueba Redis, RabbitMQ ni SMTP.
2. `backend/compose.yml` en el ZIP **sí** contiene `ports: - "27017:27017"` para MongoDB. La afirmación de que Mongo ya no se publica en el host parece pertenecer a otro cambio o versión.
3. La ruta HTTP `detectConflictsController()` llama directamente a `detectLevelOneConflicts()`. El cron de `backend/src/server.ts` sí publica la tarea programada en `tass.conflict.detection`.
4. La generación PDF/Excel del controlador pasa por `generateReportThroughQueue()` y por RabbitMQ RPC.
5. El frontend se compila con Node y se sirve con Nginx estático. Aunque el repositorio contiene archivos de SSR, el Dockerfile final revisado copia el bundle `browser` a Nginx y no ejecuta el servidor SSR Node.
6. La documentación de Redis indica que algunas cachés de empleados/conflictos no se invalidan automáticamente al escribir en MongoDB; los datos pueden quedar desactualizados hasta vencer el TTL.

---

**Fin de la guía.** Para estudiar, intenta responder la pregunta de autoevaluación de cada sección con tus propias palabras y luego comprueba la respuesta en el apartado correspondiente. Para defender la arquitectura ante un desarrollador senior, explica siempre el recorrido completo: interfaz → HTTP → ruta/controlador → servicio → dependencia externa → persistencia/respuesta → log o notificación.
