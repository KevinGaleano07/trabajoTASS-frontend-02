# Informe de estudio: Aplicación TASS

**Alcance:** frontend Angular y backend Express/MongoDB, según el código presente en los repositorios `trabajoTASSfrontend` y `trabajoTASS-backend`.

Este documento sirve como guía para exponer la aplicación y responder preguntas sobre su arquitectura, pantallas, datos, permisos, errores y flujo entre navegador, API y base de datos.

## 1. Resumen de la aplicación

TASS permite registrar usuarios autorizados, declarar relaciones familiares, detectar posibles conflictos de interés y presentar esos conflictos a personal administrativo para revisión. El administrador puede consultar métricas, filtrar conflictos y descargarlos en PDF o Excel. El super administrador puede consultar las cuentas que tienen rol `admin`.

La aplicación tiene dos partes independientes que se comunican por HTTP:

- **Frontend:** Angular 21. Captura entradas, mantiene estado de pantalla, llama a la API y pinta respuestas.
- **Backend:** Node.js, Express, TypeScript y Mongoose. Valida solicitudes, autentica usuarios, verifica permisos y consulta o modifica MongoDB.

Flujo general de una solicitud:

```text
Componente/plantilla Angular
  -> servicio Angular / HttpClient
  -> URL de entorno + interceptor JWT
  -> ruta Express
  -> middleware de autenticación/rol (si aplica)
  -> controlador
  -> servicio de dominio
  -> modelo Mongoose
  -> MongoDB
  -> respuesta JSON o archivo
  -> componente actualiza su estado
  -> plantilla renderiza los datos
```

## 2. Estructura del frontend

### Arranque y configuración

- `src/main.ts` inicia la aplicación Angular mediante `bootstrapApplication`.
- `src/app/app.ts` es el componente raíz y contiene el `router-outlet` principal.
- `src/app/app.config.ts` registra el router, `HttpClient`, el interceptor de autenticación y la hidratación para SSR.
- `src/app/app.routes.ts` relaciona rutas, componentes, guards y roles permitidos.
- `src/enviroments/enviroment*.ts` define las URL de API para local, desarrollo y preproducción. El directorio se llama intencionalmente `enviroments`.
- `src/assets/` contiene imágenes como los logos TASS.

### Capas y responsabilidades

- `src/app/core/`: servicios, guards e interceptor compartidos.
- `src/app/features/`: flujos como login/registro y el shell autenticado.
- `src/app/pages/`: pantallas de perfil, usuario, administrador, documentos, configuración y super administrador.
- `src/app/shared/`: componentes reutilizables como header y navbar.
- `src/app/utils/`: interfaces y tipos de datos TypeScript.

Un componente suele tener una clase `.ts`, plantilla `.html` y estilos `.css`. La clase carga datos y gestiona interacciones; la plantilla usa interpolación (`{{ valor }}`), condiciones (`@if`) y ciclos (`@for`) para mostrarlos. Los formularios usan Reactive Forms; algunos filtros usan `ngModel`.

## 3. Estructura del backend

- `src/server.ts`: crea Express, configura JSON y CORS, monta rutas, inicia MongoDB, programa la detección diaria y escucha en el puerto configurado.
- `src/config/env.ts`: obtiene configuración del entorno y carga `.env.<NODE_ENV>` desde el directorio de ejecución. El servidor no inicia si faltan variables obligatorias o MongoDB no conecta.
- `src/routes/`: declara endpoints y middlewares requeridos.
- `src/middlewares/`: autenticación JWT, autorización por rol y manejo global de errores.
- `src/controllers/`: adapta la solicitud HTTP al servicio y construye la respuesta HTTP.
- `src/services/`: reglas de negocio, consultas y generación de documentos.
- `src/models/`: esquemas y modelos Mongoose.
- `src/validators/`: reglas explícitas de validación, especialmente para registro.

Las rutas se montan en `src/routes/index.routes.ts` bajo `/api`. El servidor usa `express.json()` para interpretar cuerpos JSON y CORS permite solicitudes desde navegadores.

## 4. Datos principales

### Usuario

`backend/src/models/User.ts` define nombres, apellidos, tipo y número de documento, correo, teléfono, `tipoVinculacion`, `rolSistema`, cargo, empresa proveedora, estado y `passwordHash`.

- `rolSistema`: `usuario`, `admin` o `superAdmin`; decide permisos.
- `tipoVinculacion`: `empleado`, `administrativo`, `directivo` o `proveedor`; describe la relación organizacional.
- Estado: `PENDIENTE`, `ACTIVO` o `INACTIVO`.
- La contraseña se guarda como hash bcrypt y el campo `passwordHash` está excluido por defecto en consultas.
- Hay índices únicos para correo y para el par tipo/número de documento.

No se deben confundir rol y vinculación: un proveedor, por ejemplo, puede tener `rolSistema: 'usuario'` y `tipoVinculacion: 'proveedor'`.

### Otros modelos

- **Company:** NIT, nombre y estado (`ACTIVA`/`INACTIVA`).
- **AuthorizedPerson:** tipo/número de documento, cargo y estado. Se usa para validar que una persona puede crear cuenta.
- **FamilyRelationship:** IDs de usuario y familiar, parentesco y fechas. Un índice único evita duplicar la misma relación en la misma dirección.
- **FamilyDeclaration:** otro modelo de relación familiar con campos propios. Tiene una ruta separada; el formulario actual consulta y crea usando `FamilyRelationship`.
- **Conflict:** código, nivel, estado, categoría, declarante, parentesco, fechas, involucrados, coincidencias, descripción, evidencias, notas, investigador, resolución y audit log.

### Formas de respuesta

La API suele responder JSON con `success`, `data` y, cuando aplica, `message` o `total`. Ejemplo conceptual:

```json
{
  "success": true,
  "message": "Operación completada",
  "data": {}
}
```

Una lista normalmente vive en `data: []`; una respuesta binaria de reporte no usa ese sobre JSON, sino un `Buffer` con encabezados de descarga.

## 5. Registro, activación, login y sesión

### Registro

1. `src/app/features/auth/register/register.ts` valida campos en el navegador y arma un `RegisterRequest`: nombres, apellidos, documento, correo, teléfono, vinculación, cargo, contraseña y confirmación. Para proveedores consulta primero la empresa por NIT.
2. `AuthServiceTs.register()` manda `POST /api/auth/register`.
3. El backend ejecuta `validateRegistration()` y normaliza correo/documento. Comprueba duplicados, empresa cuando corresponde, persona autorizada activa y coincidencia del cargo.
4. Cifra la contraseña con bcrypt y crea un usuario con rol inicial `usuario` y estado `PENDIENTE`.
5. Genera un token de verificación de correo con vigencia de un día, envía el email y devuelve un mensaje de cuenta pendiente.
6. `GET /api/auth/verify-email?token=...` verifica el token, actualiza el usuario a `ACTIVO` y redirige a login.

La validación del backend es la autoridad. La interfaz además impone reglas propias; por ejemplo, el formulario frontend pide una longitud mínima de 10 para documento, mientras que el validador backend general acepta de 3 a 20 antes de reglas específicas por tipo. Por ello, puede haber diferencias entre lo que acepta cada capa.

### Login

1. El formulario manda `POST /api/auth/login` con correo y contraseña.
2. El backend normaliza el correo, busca al usuario incluyendo `passwordHash`, compara con bcrypt y exige `estado === 'ACTIVO'`.
3. Si es válido, genera un JWT de una hora. El payload contiene el ID y datos de identidad, vinculación, rol, cargo y estado.
4. `AuthServiceTs.login()` guarda el JWT en `localStorage`.
5. Login lee el rol y navega a `/home`, `/admin` o `/super-admin`.

El frontend decodifica el payload para pintar nombre, avatar con iniciales y menú. Decodificar no valida la firma: el backend verifica el JWT en cada endpoint protegido.

### Cambio de contraseña y sesión

`PATCH /api/auth/change-password` requiere `authMiddleware`. El backend toma el usuario del token, verifica la contraseña actual, cifra la nueva y actualiza MongoDB. La pantalla Perfil confirma el resultado y cierra la sesión, exigiendo volver a iniciar sesión.

## 6. Rutas, permisos y perfiles

`src/app/app.routes.ts` declara las rutas. La ruta raíz redirige a login; login y registro son públicos. Las demás pantallas autenticadas usan `Home` como contenedor padre.

| Pantalla/ruta | Acceso configurado en frontend |
|---|---|
| `/perfil` | Cualquier usuario con token |
| `/home` | `usuario` |
| `/admin` y sus hijos | `admin` |
| `/super-admin` | `superAdmin` |
| `/documentos` | `admin`, `superAdmin` |
| `/configuracion` | `admin`, `superAdmin` |

### Shell compartido

`src/app/features/home/home.html` contiene header, menú/navbar y un `<router-outlet />`. `home.ts` lee `rolSistema` y construye `navItems`; la URL de cada item navega, su `icon` elige el Material Icon, y `routerLinkActive` resalta la sección activa.

Por lo tanto, hay **una base visual reutilizada**, pero no una sola pantalla con todo el contenido. El router monta distintos componentes hijos. Los guards del frontend evitan navegar a vistas no permitidas y `rolesGuard` redirige a `/home` cuando el rol no está autorizado.

### Autorización backend

`authMiddleware` lee `Authorization: Bearer <token>`, verifica firma/expiración y agrega el payload a `request.user`. `authorizeRoles(...)` compara exactamente `request.user.rolSistema` con los roles permitidos. Esta validación backend protege los datos aunque alguien evite la navegación frontend.

`admin` y `superAdmin` pueden consultar/gestionar conflictos y reportes en `/api/conflicts`. El endpoint `GET /api/admin/administrators` requiere `superAdmin` y devuelve únicamente usuarios con rol `admin`, seleccionando campos públicos.

## 7. Funcionalidades y flujo de datos

### Familiares del usuario

- Al abrir `UserHome`, `FamilyService.getFamilyRelationships()` llama `GET /api/families`.
- Backend toma el ID del usuario autenticado y busca relaciones donde ese ID sea `usuario`; hace `populate('familiar', ...)` para devolver datos limitados del usuario familiar.
- La pantalla guarda `response.data` y pinta filas con nombre, parentesco y vinculación.
- Crear familiar manda `POST /api/families`. El backend busca una cuenta `ACTIVO` por tipo y número de documento, evita autorrelación y duplicados, y persiste la referencia familiar junto con el parentesco.
- Esto **no crea una cuenta nueva**. La interfaz contiene datos como nombres/cargo/teléfono, pero el servicio backend actual resuelve el familiar por documento y persiste principalmente los IDs y parentesco; los campos extra no se convierten en datos del usuario.

### Empresas y personas autorizadas

- `CompanyService.findByNit()` consulta `GET /api/company/nit/:nit`; lo usa el registro para confirmar proveedores.
- Existe `POST /api/company` para crear empresas y `POST /api/authorized-persons` para crear personas autorizadas.
- En el frontend actual no hay servicios/pantallas encontrados que llamen a esos dos `POST`.
- Esas rutas y la consulta de empresa no tienen `authMiddleware`/`authorizeRoles` en sus definiciones actuales. Su disponibilidad debe entenderse como comportamiento actual de rutas, no como recomendación de seguridad.

### Dashboard y conflictos del administrador

- Al inicializar, `AdminHome` hace dos solicitudes: `GET /api/conflicts/dashboard-stats` y `GET /api/conflicts`.
- Dashboard pinta usuarios activos, total de conflictos, alto riesgo, pendientes, tasa de resolución y tiempo promedio.
- Las subsecciones llamadas Empleados, Administrativos, Directivos y Proveedores importan el mismo `ConflictTable` y cambian su `@Input() categoria`. Son listados de conflictos por categoría, no un módulo CRUD de esos empleados.
- `ConflictTable` vuelve a consultar la lista de conflictos, filtra localmente por categoría y luego por texto, nivel y estado. El modal pinta el objeto seleccionado, incluyendo involucrados y coincidencias.
- `POST /api/conflicts/detect` ejecuta detección manual; al completarse, el dashboard vuelve a solicitar estadísticas y lista.
- El backend también ejecuta detección diaria con cron a las 16:08, zona `America/Bogota`.

### Cómo se detecta un conflicto

`detectLevelOneConflicts()` consulta usuarios activos (incluye NIT de empresa para proveedores) y relaciones familiares. Construye un mapa por ID, recorre las relaciones, ignora usuarios faltantes/inactivos, calcula categoría y nivel, revisa si ya existe conflicto y genera códigos `CON-<año>-<número>`. Los conflictos nuevos empiezan en `PENDIENTE`, guardan dos involucrados como snapshot y se insertan en MongoDB.

La detección actual es específicamente por relación familiar entre usuarios activos; no es un motor de reglas general. El cálculo de nivel tiene una condición duplicada: el comentario menciona empleado-administrativo, pero la segunda condición vuelve a comprobar empleado-proveedor. Además, la clave del par no ordena los IDs pese a que el comentario dice que evita comparar una pareja al revés; esas condiciones son puntos que conviene explicar como límites o revisar antes de ampliar reglas.

### Estado del conflicto

- `PUT /api/conflicts/:id/status` recibe `{ estado }` y valida que el ID Mongo sea válido.
- El servicio actual admite las acciones de resolver (`RESUELTO`) y devolver de resuelto a pendiente (`PENDIENTE`); limpiar o fijar `fechaResolucion` según transición.
- En la interfaz las dos acciones requieren confirmación. La respuesta sustituye el objeto de la lista y el seleccionado para que tabla y modal muestren el nuevo estado.

### Documentos PDF y Excel

- Documentos manda `POST /api/conflicts/report` con `{ formato: 'pdf' | 'excel' }`.
- El servicio backend consulta conflictos ordenados por fecha; PDFKit genera PDF y ExcelJS construye XLSX. El controlador devuelve un buffer con `Content-Type` y `Content-Disposition` para descargar.
- Angular recibe `Blob`, crea una URL temporal, pulsa un enlace de descarga y luego revoca la URL. Para errores HTTP, intenta interpretar el cuerpo Blob como JSON y mostrar su mensaje; también rechaza respuestas vacías.

### Perfil, configuración y super-admin

- Perfil obtiene nombre, correo y rol del token; calcula iniciales con primera letra del nombre y apellido. El formulario de contraseña valida coincidencia y complejidad antes de llamar al servicio.
- Configuración muestra datos de cuenta y enlaces a perfil/seguridad/panel. No guarda preferencias globales ni ajustes de sistema en backend.
- Super Admin carga administradores desde `GET /api/admin/administrators`, muestra estados de carga/error/vacío, permite reintentar y presenta nombre, correo, cargo, vinculación y estado.

## 8. Endpoints principales

| Método y endpoint | Función | Protección declarada |
|---|---|---|
| `POST /api/auth/register` | Registrar cuenta pendiente y enviar verificación | Pública |
| `GET /api/auth/verify-email` | Activar cuenta por token | Token de verificación |
| `POST /api/auth/login` | Validar credenciales y devolver JWT | Pública |
| `PATCH /api/auth/change-password` | Cambiar contraseña | JWT |
| `GET/POST /api/families` | Listar/crear relación familiar | JWT |
| `POST /api/family-declarations` | Crear declaración familiar alternativa | JWT |
| `GET /api/company/nit/:nit` | Buscar empresa | Sin middleware declarado |
| `POST /api/company` | Crear empresa | Sin middleware declarado |
| `POST /api/authorized-persons` | Crear persona autorizada | Sin middleware declarado |
| `GET /api/conflicts` | Listar conflictos | `admin`, `superAdmin` |
| `GET /api/conflicts/dashboard-stats` | Métricas | `admin`, `superAdmin` |
| `GET /api/conflicts/:id` | Detalle de conflicto | `admin`, `superAdmin` |
| `POST /api/conflicts/detect` | Detección manual | `admin`, `superAdmin` |
| `PUT /api/conflicts/:id/status` | Cambiar estado | `admin`, `superAdmin` |
| `POST /api/conflicts/report` | PDF o Excel | `admin`, `superAdmin` |
| `GET /api/admin/administrators` | Listar usuarios con rol admin | `superAdmin` |

El mismo router familiar también está montado como `/api/family-relationships`; la interfaz usa `/api/families`.

## 9. Manejo de errores

### Frontend

- Validadores de formularios impiden solicitudes incompletas y marcan controles.
- Los componentes capturan errores de `HttpClient`, priorizan `error.error.message` y muestran alertas con `SweetAlertService` o un mensaje en página.
- El interceptor maneja específicamente HTTP 401: borra token y navega a login. No es el encargado de mostrar todos los mensajes de error.

### Backend

- Controladores capturan errores con `try/catch` y los pasan a `next`; Express 5 también propaga rechazos de handlers asíncronos.
- `errorHandler` está al final de la cadena. Conserva errores `AppError` o normaliza duplicados Mongo (409), ObjectId inválido (400), validaciones Mongoose (400) y errores desconocidos (500).
- Respuesta común: `{ success: false, message, code, details }`.
- Hay clases `ValidationError`, `ConflictError`, `AuthenticationError`, `AuthorizationError`, `NotFoundError`, `DatabaseError`, `ExternalServiceError` e `InternalServerError`; no todas se usan en todos los flujos. Por ejemplo, algunos errores de autenticación sin token se crean como validación 400, mientras que el token expirado responde 401 y rol incorrecto 403.
- Observación de seguridad: el middleware devuelve `details` actualmente; el comentario que indica ocultarlos en producción está desactivado, y los errores desconocidos pueden incluir detalles/stack según el entorno.

## 10. Límites y puntos para explicar con precisión

1. Guard frontend no es seguridad suficiente; la API debe mantener sus middlewares.
2. El interceptor y `authGuard` acceden a `localStorage` directamente. Dado que Angular está configurado con SSR, cambios de autenticación deben contemplar ejecución sin `window/localStorage`.
3. La lista de administradores sí consulta backend; las pantallas por tipo de vinculación en `/admin/...` actualmente presentan conflictos asociados a esa categoría.
4. `FamilyDeclaration` y `FamilyRelationship` son modelos distintos; la vista actual consume el segundo.
5. Alta de empresas/personas autorizadas tiene endpoints backend, pero no un flujo frontend conectado en el código revisado.
6. Los usuarios se crean con rol `usuario`; esta implementación de registro no permite escoger rol admin.
7. El endpoint de conflictos devuelve la lista completa a roles admin/superAdmin; el filtro por categoría ocurre en Angular. Los reportes también consultan los conflictos del sistema, no solo una categoría.
8. El porcentaje de resolución se calcula a partir de conflictos resueltos y aplica una penalización por pendientes con más de dos días; el promedio de resolución se obtiene de diferencia entre detección y resolución.

## 11. Respuestas breves para una exposición

- **¿Cómo sabe qué perfil mostrar?** El backend incorpora `rolSistema` en el JWT; Angular lo lee para construir el menú y el login elige una ruta. Los guards comprueban el rol de las rutas y Express vuelve a comprobar permisos al servir datos.
- **¿Cómo llegan datos a MongoDB?** El formulario crea un objeto; un servicio Angular hace HTTP; la ruta Express pasa por middleware/controlador/servicio; Mongoose valida y guarda el documento.
- **¿Cómo regresan y se muestran?** El controlador responde JSON o un buffer; el servicio Angular tipa la respuesta; el componente la asigna a su estado; Angular recorre/condiciona la plantilla para pintarla.
- **¿De dónde sale un conflicto?** De relaciones familiares entre usuarios activos según la detección de nivel 1, manual o programada; la API devuelve los documentos y el administrador los revisa en tablas filtrables.
- **¿Dónde se autorizan los datos?** En las rutas backend con `authMiddleware` y `authorizeRoles`; los guards del navegador controlan navegación, no reemplazan esa autorización.

## 12. Comandos

- Frontend: `npm run start:local` (puerto 11001), `npm run build`, `npm test`.
- Backend: `npm run dev:local`, `npm run dev`, `npm run build`.
- Frontend usa Vitest mediante Angular CLI. El backend no declara un script de pruebas en su `package.json`.
