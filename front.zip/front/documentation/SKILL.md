---
name: angular-feature
description: Planificar e implementar una funcionalidad Angular en TASS respetando la versión y los patrones actuales.
---

# Skill: funcionalidad Angular TASS

## Cuándo usar
Cuando se solicite crear o modificar una página, componente, formulario o flujo del frontend TASS.

## Procedimiento
1. Inspecciona el componente, template, estilos, rutas, servicios, modelos e interceptores relacionados.
2. Confirma si el módulo usa standalone, Reactive Forms, Signals, RxJS y control de flujo `@if`/`@for`; sigue el patrón real.
3. Describe el flujo desde la interacción del usuario hasta la llamada al backend y el tratamiento de la respuesta.
4. Define estados de carga, éxito, error, formulario inválido y ausencia de datos cuando correspondan.
5. Mantén las validaciones de interfaz alineadas con las reglas conocidas, sin sustituir las validaciones del backend.
6. Implementa el cambio mínimo y conserva accesibilidad, etiquetas, mensajes claros y manejo de errores.
7. Diseña o ajusta pruebas usando el framework ya configurado en el repositorio.
8. Ejecuta las pruebas/build disponibles y reporta los resultados reales.

## Restricciones
- No migrar APIs o patrones Angular por preferencia personal.
- No instalar librerías sin justificar el beneficio y el coste.
- No poner secretos ni reglas sensibles únicamente en el frontend.
- No inventar endpoints ni modelos de respuesta.
- No afirmar que el flujo completo funciona si solo se compiló el frontend.

## Formato de salida
1. Archivos inspeccionados.
2. Flujo actual.
3. Cambio propuesto.
4. Pruebas y resultados.
5. Pendientes de integración con backend.
