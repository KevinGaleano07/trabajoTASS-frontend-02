# Instrucciones generales para GitHub Copilot — TASS Frontend

## Contexto
- Frontend de TASS en Angular. El proyecto informado por el equipo usa Angular 21.2.20.
- Revisa `package.json`, `angular.json`, rutas y estructura real antes de asumir versiones o patrones.
- La API es un backend Express/TypeScript separado; no inventes endpoints ni contratos.

## Reglas obligatorias
1. Antes de editar, identifica archivos y flujo actuales; presenta un plan breve y espera aprobación si la tarea es amplia o cambia arquitectura.
2. Trabaja solo en la fase y el alcance que el usuario autorizó. No continúes automáticamente con otra HU.
3. Prefiere cambios pequeños, consistentes con el estilo del repositorio. No reescribas archivos completos sin necesidad.
4. Usa patrones compatibles con la versión instalada de Angular. Cuando encaje con el proyecto, considera standalone y el control de flujo moderno (`@if`, `@for`, `@switch`); no migres patrones sin autorización.
5. Mantén la lógica de presentación separada de acceso a datos; usa servicios e inyección de dependencias siguiendo el patrón existente.
6. Respeta tipado TypeScript, validación de formularios, estados de carga, éxito y error. No ocultes errores ni dejes botones cargando indefinidamente.
7. No añadas dependencias ni cambies configuración global sin explicar el motivo y el impacto.
8. No inventes pruebas ni digas que algo pasó si no ejecutaste el comando. Indica comandos y resultados reales.
9. No leas, imprimas ni incluyas secretos de `.env`. Usa `.env.example` y nombres de variables sin valores reales.
10. No cambies contratos API, autenticación, permisos o validaciones de negocio sin autorización.

## Al terminar cada tarea
- Resume archivos modificados y por qué.
- Explica el flujo funcional.
- Ejecuta pruebas/build pertinentes o di claramente qué no pudiste ejecutar.
- Lista riesgos y pasos manuales pendientes.
- No avances a la siguiente fase sin confirmación del usuario.
