# Mensajería RabbitMQ en TASS

El backend se conecta mediante `RABBITMQ_URL` al host interno `rabbitmq:5672`, usuario de aplicación `tass_backend` y vhost `tass`. La contraseña debe estar codificada para URL si contiene caracteres reservados. La conexión se reutiliza y se cierra al recibir SIGINT/SIGTERM.

## Colas y dead-letter

Las colas principales son durables. El exchange `tass.dlx` es `fanout` y envía mensajes muertos a una DLQ independiente por tipo:

| Cola principal | TTL de mensaje | Máximo | Cola DLQ |
|---|---:|---:|---|
| `tass.conflict.detection` | 3 600 000 ms | 10 000 | `tass.conflict.detection.dlq` |
| `tass.email.notification` | 86 400 000 ms | 50 000 | `tass.email.notification.dlq` |
| `tass.report.generation` | 86 400 000 ms | 5 000 | `tass.report.generation.dlq` |

Las colas DLQ son durables. Los límites para email/reporte y el dead-letter exchange se aplican mediante policies para evitar redeclarar colas existentes con argumentos incompatibles. La cola de conflictos ya tenía el DLX como argumento.

## Flujo

```mermaid
flowchart LR
  P[Backend producer] --> C[tass.conflict.detection]
  P --> E[tass.email.notification]
  P --> R[tass.report.generation]
  C --> CC[Consumer de conflictos]
  E --> EC[Consumer de correo]
  R --> RC[Consumer de reportes]
  C -. fallo tras un reintento .-> X[tass.dlx]
  E -. fallo tras un reintento .-> X
  R -. fallo tras un reintento .-> X
  X --> CD[tass.conflict.detection.dlq]
  X --> ED[tass.email.notification.dlq]
  X --> RD[tass.report.generation.dlq]
```

El productor publica JSON persistente y espera confirmación del broker. Cada consumer usa `prefetch(1)`, confirma (`ack`) al completar el handler y reintenta una vez; una segunda falla se rechaza sin requeue para enviarla a su DLQ.

## Flujos integrados

- Registro: encola el identificador del usuario después de guardarlo. El consumer genera el token de verificación y envía el correo; el endpoint no espera al SMTP.
- Detección: el cron encola el trabajo y el consumer ejecuta la detección. `POST /api/conflicts/detect` conserva su respuesta síncrona.
- Reportes: conserva la respuesta y descarga PDF/Excel actuales. El endpoint publica un trabajo persistente y espera al consumer por Direct Reply-to. El timeout se configura con `REPORT_RESPONSE_TIMEOUT_MS` (120 000 ms por defecto), sin crear otra cola.
- Notificaciones a Super Admin: se persisten en Mongo y se transmiten por SSE, fuera de RabbitMQ.
- Auditoría: se conserva el `auditLog` existente en los conflictos; no se agregó una cola separada.

## Configuración

```env
RABBITMQ_URL=amqp://tass_backend:CAMBIAR_PASSWORD_URL_ENCODED@rabbitmq:5672/tass
```

El broker requiere además las contraseñas de sus usuarios configuradas por Compose. No incluir credenciales reales en este documento.

`REPORT_RESPONSE_TIMEOUT_MS=120000` configura el máximo de espera de la descarga.

## Instalación local

Configura las variables requeridas en `.env.dev` y ejecuta:

```powershell
docker compose --env-file .env.dev up -d --build
docker compose --env-file .env.dev ps
```

Para el servidor, suministra las mismas variables desde su entorno de despliegue; no uses `localhost` para conectar contenedores.

## Verificación ejecutada

| Comprobación | Resultado |
|---|---|
| Conexión autenticada del backend al broker | PASS |
| Publicación persistente y recepción en las tres colas | PASS |
| Reintento de un mensaje fallido y `ack` al segundo intento | PASS (2 entregas) |
| Segundo fallo enviado a DLQ | PASS (1 mensaje en la DLQ esperada) |
| Reportes PDF y Excel generados por el consumer con respuesta RPC | PASS |
| Mensaje persistente conservado tras reiniciar RabbitMQ | PASS |
| Entrega y `ack` del mensaje recuperado al iniciar el backend | PASS |
| Seis colas durables y profundidad final de todas las colas | PASS (0 mensajes) |

Los mensajes de prueba fueron sintéticos y se purgaron las DLQ al terminar. Se observaron los eventos `rabbitmq.message.published`, `rabbitmq.*.message.received`, `rabbitmq.consumer.message_requeued` y `rabbitmq.consumer.message_dead_lettered`. Las pruebas fueron efímeras; no se añadió un script ni quedaron mensajes de prueba en las colas.

No se envió correo real durante las pruebas para evitar exponer tokens a un proveedor SMTP. La ruta SSE depende de que la instancia que procesa la detección mantenga la conexión del cliente; el Compose actual usa una instancia de backend.
