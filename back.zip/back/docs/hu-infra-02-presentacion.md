# HU-INFRA-02 — Presentación técnica

## 1. Objetivo

Preparar Redis para caché temporal y RabbitMQ para trabajo asíncrono, manteniendo MongoDB como fuente de verdad y permitiendo configurar los servicios por entorno.

## 2. Arquitectura

```mermaid
flowchart LR
  B[Backend] <--> R[Redis<br/>caché temporal]
  B --> P[Productor RabbitMQ]
  P --> C[tass.conflict.detection]
  P --> E[tass.email.notification]
  P --> G[tass.report.generation]
  C --> CC[Consumer placeholder]
  E --> EC[Consumer placeholder]
  G --> GC[Consumer placeholder]
  C -. fallo tras reintento .-> DLX[tass.dlx]
  E -. fallo tras reintento .-> DLX
  G -. fallo tras reintento .-> DLX
  DLX --> DC[tass.conflict.detection.dlq]
  DLX --> DE[tass.email.notification.dlq]
  DLX --> DG[tass.report.generation.dlq]
  B --> M[(MongoDB<br/>fuente de verdad)]
```

## 3. Redis

- Helpers `get`, `set`, `del`, `exists` e incremento atómico con TTL.
- Sesiones/logout, bloqueo de login, listados de empleados, consultas de conflictos y contador de notificaciones usan los TTL definidos.
- Caché efímera, con límite de memoria y expulsión LRU.
- El backend usa DNS interno `redis`; Redis no publica su puerto al host.
- No se invalida automáticamente la caché de empleados/conflictos por escrituras Mongo.

## 4. RabbitMQ

- Tres colas de negocio durables y una DLQ durable para cada una.
- Productor JSON persistente con confirmación del broker.
- Consumers con `prefetch(1)`, `ack` tras éxito y un reintento antes de dead-letter.
- El correo de verificación y la detección programada se procesan mediante consumers.
- Los reportes se generan en el consumer y responden por Direct Reply-to; el HTTP mantiene la descarga síncrona.

## 5. Portabilidad y puesta en marcha

En local, las variables se cargan desde `.env.dev`; en servidor se suministran desde el entorno de despliegue. No se codifican direcciones locales en los clientes de Redis/RabbitMQ.

```powershell
docker compose --env-file .env.dev up -d --build
docker compose --env-file .env.dev ps
```

## 6. Verificación ejecutada

- Redis: conexión, `PING`, JSON set/get, `exists`, `del`, miss y expiración TTL: PASS.
- RabbitMQ: publicación/consumo en tres colas, reintento, DLQ y mensaje persistente tras reinicio: PASS.
- APIs: rate limit, sesión/logout, listado paginado, notificaciones REST/SSE y descarga PDF: PASS.
- Benchmark sintético: MongoDB 1,262 ms mediana; Redis 0,770 ms (reducción 39,0 %).
- Al final, los cinco servicios estuvieron saludables y las seis colas quedaron sin mensajes.
- `npm test`: 6 pruebas aprobadas, 0 fallidas.

## 7. Pendientes y límites

- El benchmark es local y sintético; medir producción requiere una prueba de carga dedicada.
- El envío SMTP real no se probó para evitar enviar tokens a un proveedor externo.
- SSE vive en la instancia backend que procesa el conflicto; escalar requiere un bus compartido.
- La auditoría permanece en el `auditLog` existente y no usa una cola separada.
- No se modificaron autenticación, registro ni lógica funcional de HU previas.
