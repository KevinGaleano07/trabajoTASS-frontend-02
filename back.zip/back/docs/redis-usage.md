# Uso de Redis en TASS

Redis se usa únicamente como caché temporal; MongoDB continúa siendo la fuente de verdad. La conexión del backend usa `REDIS_URL` y, si no se define, el DNS de Compose `redis:6379`.

Redis desactiva el modo protegido para aceptar conexiones entre contenedores sin contraseña. El puerto `6379` solo se expone en la red interna de Compose, no se publica en el host; no publiques ese puerto ni conectes servicios no confiables a `tass-network`.

## TTL configurables

Los valores están expresados en segundos y pueden sobrescribirse mediante variables de entorno:

| Variable | Uso previsto | Predeterminado |
|---|---|---:|
| `REDIS_TTL_SESSION` | Sesión JWT | 3600 |
| `REDIS_TTL_EMPLOYEES` | Listados de empleados | 600 |
| `REDIS_TTL_CONFLICTS` | Resultados/listados de conflictos | 300 |
| `REDIS_TTL_NOTIFICATIONS` | Contadores de notificaciones no leídas | 60 |

`src/services/cacheService.ts` expone `get`, `set`, `del` y `exists`, y el objeto `CACHE_TTL` para pasar el TTL correspondiente a `set`. Las lecturas registran hit/miss sin incluir claves ni valores en el log.

## Estado de integración

- Las sesiones JWT se guardan por `jti`; el middleware rechaza sesiones ausentes o revocadas. `POST /api/auth/logout` registra la revocación hasta la expiración del token.
- El login limita a 5 fallos por cuenta normalizada durante 15 minutos. Las claves almacenan un hash del correo, no el dato original.
- `GET /api/admin/employees` cachea páginas de empleados (`tipoVinculacion=empleado`).
- Los listados, detalles y estadísticas de conflictos se cachean con TTL de 5 minutos.
- `GET /api/notifications/unread-count` cachea el contador por usuario; crear/marcar leídas actualiza el valor cacheado si existe.

No se invalida automáticamente la caché de empleados o conflictos al escribir en MongoDB; esos datos pueden quedar obsoletos hasta su TTL.

## Variables

```env
REDIS_URL=redis://redis:6379
REDIS_TTL_SESSION=3600
REDIS_TTL_EMPLOYEES=600
REDIS_TTL_CONFLICTS=300
REDIS_TTL_NOTIFICATIONS=60
LOGIN_MAX_FAILED_ATTEMPTS=5
LOGIN_ATTEMPT_WINDOW_SECONDS=900
```

No se configura persistencia de Redis: perder la caché al reiniciar es intencional.

## Instalación local

Configura las variables requeridas en `.env.dev` y ejecuta:

```powershell
docker compose --env-file .env.dev up -d --build
docker compose --env-file .env.dev ps
```

Redis no publica puertos al host; el backend lo resuelve por el nombre de servicio `redis`. En el servidor se cambian las variables de entorno, no el código.

## Verificación

Pruebas smoke ejecutadas desde el contenedor backend con una clave temporal única:

| Comprobación | Resultado |
|---|---|
| Guardar y recuperar JSON | PASS |
| `exists` antes/después de borrar | PASS |
| `del` y miss posterior | PASS |
| Expiración con TTL de 1 segundo | PASS |
| Lectura de los cuatro TTL desde entorno | PASS |
| Conexión desde backend (`PING`) | PASS |
| 5 intentos fallidos y bloqueo del siguiente | PASS |
| Crear sesión, logout y rechazo del token revocado | PASS |
| Listado paginado de empleados | PASS |
| Contador de notificaciones, listado y marcado leído | PASS |
| Latencia mediana: MongoDB 1,262 ms vs caché Redis 0,770 ms | PASS |

La medición comparó 25 lecturas de una lista sintética idéntica en una base temporal aislada; la mediana Redis fue 39,0 % menor. Es una medición local pequeña, no una garantía de rendimiento en producción. Los logs mostraron `cache.hit` y `cache.miss` sin incluir claves ni valores. Los smoke tests usaron datos temporales y no se añadió un script de prueba.
