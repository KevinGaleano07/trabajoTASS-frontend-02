import { randomUUID } from 'node:crypto';
import { connectRabbitMQ } from '../config/rabbitmq.js';
import { ExternalServiceError, AppError } from '../utils/errors.js';
import { ErrorCatalog } from '../utils/errorCatalog.js';
import { TASS_QUEUES } from './messageProducer.js';

const REPORT_RESPONSE_TIMEOUT_MS = Number(process.env.REPORT_RESPONSE_TIMEOUT_MS ?? 120_000);

export async function generateReportThroughQueue(format: 'pdf' | 'excel'): Promise<Buffer> {
  if (!Number.isSafeInteger(REPORT_RESPONSE_TIMEOUT_MS) || REPORT_RESPONSE_TIMEOUT_MS <= 0) {
    throw new Error('REPORT_RESPONSE_TIMEOUT_MS must be a positive integer');
  }

  const connection = await connectRabbitMQ();
  const channel = await connection.createConfirmChannel();
  const correlationId = randomUUID();
  let resolveReply!: (content: Buffer) => void;
  let rejectReply!: (error: Error) => void;
  const reply = new Promise<Buffer>((resolve, reject) => {
    resolveReply = resolve;
    rejectReply = reject;
  });

  const { consumerTag } = await channel.consume(
    'amq.rabbitmq.reply-to',
    (message) => {
      if (!message || message.properties.correlationId !== correlationId) {
        return;
      }

      if (message.properties.contentType === 'application/json') {
        rejectReply(new AppError(
          'No fue posible generar el reporte.',
          502,
          ErrorCatalog.T505.codigo,
        ));
        return;
      }
      resolveReply(message.content);
    },
    { noAck: true },
  );

  const timeout = setTimeout(() => {
    rejectReply(new ExternalServiceError(
      'RabbitMQ',
      'La generación del reporte excedió el tiempo de espera.',
      504,
    ));
  }, REPORT_RESPONSE_TIMEOUT_MS);

  try {
    channel.sendToQueue(
      TASS_QUEUES.reportGeneration,
      Buffer.from(JSON.stringify({ format })),
      {
        persistent: true,
        contentType: 'application/json',
        replyTo: 'amq.rabbitmq.reply-to',
        correlationId,
      },
    );
    await channel.waitForConfirms();
    return await reply;
  } finally {
    clearTimeout(timeout);
    await channel.cancel(consumerTag).catch(() => undefined);
    await channel.close().catch(() => undefined);
  }
}
