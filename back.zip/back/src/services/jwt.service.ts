  import { randomUUID } from 'node:crypto';
  import jwt from 'jsonwebtoken';
  import { env } from '../config/env.js';
  import type { JwtPayload } from '../utils/enums_types_interfaces.js'

  export function generateVerificationToken(userId: string): string {
    return jwt.sign(
      { id: userId, type: 'verify-email' },
      env.jwtSecret,
      { expiresIn: '1d' }
    );
  }

  export function verifyToken(token: string) {
    return jwt.verify(token, env.jwtSecret);
  }

  export function authSessionKey(jti: string): string {
    return `auth:session:${jti}`;
  }

  export function authBlacklistKey(jti: string): string {
    return `auth:blacklist:${jti}`;
  }

  export function generateAuthToken(user: {
  _id: unknown;
  nombres: string;
  apellidos: string;
  correo: string;
  tipoDocumento: string;
  numeroDocumento: string;
  telefono: string;
  tipoVinculacion: string;
  rolSistema: string;
  cargo: string;
  estado: string;
}) {

  const payload: JwtPayload = {
    id: String(user._id),
    nombres: user.nombres,
    apellidos: user.apellidos,
    correo: user.correo,
    tipoDocumento: user.tipoDocumento,
    numeroDocumento: user.numeroDocumento,
    telefono: user.telefono,
    tipoVinculacion: user.tipoVinculacion,
    rolSistema: user.rolSistema,
    cargo: user.cargo,
    estado: user.estado,
  };

  const jti = randomUUID();
  const token = jwt.sign(
    { ...payload, jti },
    env.jwtSecret,
    { expiresIn: '1h' },
  );
  const decoded = jwt.decode(token);

  if (!decoded || typeof decoded === 'string' || typeof decoded.exp !== 'number') {
    throw new Error('Could not determine the authentication token expiry');
  }

  return { token, jti, expiresAt: decoded.exp };
}