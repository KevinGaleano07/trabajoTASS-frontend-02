import { redisClient } from '../config/redis.js';
import { logInfo } from '../utils/logger.js';

function readTtl(name: string, fallback: number): number {
  const ttl = Number(process.env[name] ?? fallback);
  if (!Number.isSafeInteger(ttl) || ttl <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return ttl;
}

export const CACHE_TTL = {
  session: readTtl('REDIS_TTL_SESSION', 3600),
  employees: readTtl('REDIS_TTL_EMPLOYEES', 600),
  conflicts: readTtl('REDIS_TTL_CONFLICTS', 300),
  notifications: readTtl('REDIS_TTL_NOTIFICATIONS', 60),
} as const;

export async function get<T>(key: string): Promise<T | null> {
  const value = await redisClient.get(key);
  logInfo(value === null ? 'cache.miss' : 'cache.hit');
  return value === null ? null : (JSON.parse(value) as T);
}

export async function set<T>(
  key: string,
  value: T,
  ttlSeconds: number = CACHE_TTL.session,
): Promise<void> {
  if (!Number.isSafeInteger(ttlSeconds) || ttlSeconds <= 0) {
    throw new RangeError('Cache TTL must be a positive integer');
  }

  const serialized = JSON.stringify(value);
  if (serialized === undefined) {
    throw new TypeError('Cache value must be JSON-serializable');
  }

  await redisClient.set(key, serialized, {
    expiration: { type: 'EX', value: ttlSeconds },
  });
}

export async function del(key: string): Promise<number> {
  return redisClient.del(key);
}

export async function exists(key: string): Promise<boolean> {
  return (await redisClient.exists(key)) > 0;
}

export async function incrementWithTtl(key: string, ttlSeconds: number): Promise<number> {
  if (!Number.isSafeInteger(ttlSeconds) || ttlSeconds <= 0) {
    throw new RangeError('Cache TTL must be a positive integer');
  }

  const result = await redisClient.eval(
    "local count = redis.call('INCR', KEYS[1]); if count == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]); end; return count",
    { keys: [key], arguments: [String(ttlSeconds)] },
  );

  if (typeof result !== 'number') {
    throw new TypeError('Redis returned an invalid counter value');
  }
  return result;
}
