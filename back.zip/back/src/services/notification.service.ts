import mongoose from 'mongoose';
import { NotificationModel } from '../models/Notification.js';
import { UserModel } from '../models/User.js';
import { publishNotificationEvent } from './notification-stream.service.js';
import { isDuplicateKeyError } from '../middlewares/error.middleware.ts.js';
import { NotFoundError } from '../utils/errors.js';
import { CACHE_TTL, get as getCached, set as setCached } from './cacheService.js';
import { logInfo } from '../utils/logger.js';

type NewConflict = {
  _id: mongoose.Types.ObjectId;
  codigo: string;
};

export async function createConflictNotifications(conflicts: NewConflict[]): Promise<void> {
  if (conflicts.length === 0) {
    return;
  }

  const superAdmins = await UserModel.find({
    rolSistema: 'superAdmin',
    estado: 'ACTIVO',
  }).select('_id').lean();

  let createdCount = 0;
  const currentCounts = new Map<string, number | null>();
  for (const conflict of conflicts) {
    for (const admin of superAdmins) {
      const filter = {
        userId: admin._id,
        conflictId: conflict._id,
        type: 'CONFLICT_DETECTED' as const,
      };
      if (await NotificationModel.exists(filter)) {
        continue;
      }

      try {
        const notification = await NotificationModel.create({
          ...filter,
          message: `Se detectó el conflicto ${conflict.codigo}.`,
        });

        publishNotificationEvent(String(admin._id), {
          id: String(notification._id),
          type: notification.type,
          conflictId: String(notification.conflictId),
          message: notification.message,
          createdAt: notification.createdAt,
        });
        const userId = String(admin._id);
        let unreadCount = currentCounts.get(userId);
        if (unreadCount === undefined) {
          unreadCount = await getCached<number>(`notifications:unread-count:${userId}`);
          currentCounts.set(userId, unreadCount);
        }
        if (unreadCount !== null) {
          unreadCount++;
          currentCounts.set(userId, unreadCount);
          await setCached(
            `notifications:unread-count:${userId}`,
            unreadCount,
            CACHE_TTL.notifications,
          );
        }
        createdCount++;
      } catch (error) {
        if (isDuplicateKeyError(error)) {
          continue;
        }
        throw error;
      }
    }
  }

  if (createdCount > 0) {
    logInfo('notification.conflict.created', { count: createdCount });
  }
}

export async function getUnreadNotificationCount(userId: string): Promise<number> {
  const key = `notifications:unread-count:${userId}`;
  const cached = await getCached<number>(key);
  if (cached !== null) {
    return cached;
  }

  const count = await NotificationModel.countDocuments({ userId, readAt: null });
  await setCached(key, count, CACHE_TTL.notifications);
  return count;
}

export async function getNotifications(
  userId: string,
  page: number,
  limit: number,
) {
  const [notifications, total] = await Promise.all([
    NotificationModel.find({ userId })
      .select('type conflictId message readAt createdAt')
      .sort({ createdAt: -1, _id: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean(),
    NotificationModel.countDocuments({ userId }),
  ]);
  return { notifications, total };
}

export async function markNotificationRead(
  userId: string,
  notificationId: string,
) {
  if (!mongoose.isValidObjectId(notificationId)) {
    throw new NotFoundError('Notificación');
  }

  const notification = await NotificationModel.findOneAndUpdate(
    { _id: notificationId, userId, readAt: null },
    { $set: { readAt: new Date() } },
    { new: true },
  ).select('type conflictId message readAt createdAt').lean();

  if (!notification) {
    const existing = await NotificationModel.findOne({ _id: notificationId, userId })
      .select('type conflictId message readAt createdAt')
      .lean();
    if (!existing) {
      throw new NotFoundError('Notificación');
    }
    return existing;
  }

  const cacheKey = `notifications:unread-count:${userId}`;
  const cachedCount = await getCached<number>(cacheKey);
  if (cachedCount !== null) {
    await setCached(cacheKey, Math.max(0, cachedCount - 1), CACHE_TTL.notifications);
  }
  return notification;
}
