import type { Response } from 'express';

export type NotificationEvent = {
  id: string;
  type: string;
  conflictId: string;
  message: string;
  createdAt: Date;
};

const streams = new Map<string, Set<Response>>();
const heartbeats = new Map<Response, ReturnType<typeof setInterval>>();

export function subscribeToNotifications(userId: string, response: Response): void {
  response.status(200);
  response.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  response.flushHeaders();
  response.write('retry: 3000\n\n');

  let userStreams = streams.get(userId);
  if (!userStreams) {
    userStreams = new Set();
    streams.set(userId, userStreams);
  }
  userStreams.add(response);

  const heartbeat = setInterval(() => {
    response.write(': heartbeat\n\n');
  }, 25_000);
  heartbeat.unref();
  heartbeats.set(response, heartbeat);

  response.on('close', () => removeStream(userId, response));
}

export function publishNotificationEvent(userId: string, event: NotificationEvent): void {
  for (const response of streams.get(userId) ?? []) {
    response.write(`event: notification\ndata: ${JSON.stringify(event)}\n\n`);
  }
}

export function closeNotificationStreams(): void {
  for (const [userId, userStreams] of streams) {
    for (const response of userStreams) {
      removeStream(userId, response);
      response.end();
    }
  }
}

function removeStream(userId: string, response: Response): void {
  const heartbeat = heartbeats.get(response);
  if (heartbeat) {
    clearInterval(heartbeat);
    heartbeats.delete(response);
  }

  const userStreams = streams.get(userId);
  userStreams?.delete(response);
  if (userStreams?.size === 0) {
    streams.delete(userId);
  }
}
