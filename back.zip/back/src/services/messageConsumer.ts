import type { Channel, ConsumeMessage } from 'amqplib';
import { connectRabbitMQ } from '../config/rabbitmq.js';
import { TASS_QUEUES, type TassQueue } from './messageProducer.js';
import { ErrorCatalog } from '../utils/errorCatalog.js';
import { logError, logInfo } from '../utils/logger.js';
import { detectLevelOneConflicts } from './conflict.service.js';
import { UserModel } from '../models/User.js';
import { generateVerificationToken } from './jwt.service.js';
import { sendVerificationEmail } from './email.service.js';
import { generateConflictPdf } from './conflict-report-PDF.service.js';
import { generateConflictExcel } from './conflict-report-Excel.service.js';

export type MessageContext = {
  correlationId?: string;
  redelivered: boolean;
  reply: (content: Buffer, contentType: string) => void;
};

export type MessageHandler = (data: unknown, context: MessageContext) => Promise<void> | void;

const channels = new Map<TassQueue, Promise<Channel>>();
const consumerStarts = new Map<TassQueue, Promise<void>>();

function getConsumerChannel(queue: TassQueue): Promise<Channel> {
  let channelPromise = channels.get(queue);
  if (!channelPromise) {
    const pendingChannel = connectRabbitMQ()
      .then((connection) => connection.createChannel())
      .then(async (channel) => {
        channel.on('error', (error) => {
          logError('rabbitmq.consumer.channel.failed', error, {
            codigo: ErrorCatalog.T503.codigo,
            mensaje: ErrorCatalog.T503.descripcion,
            queue,
          });
        });
        channel.on('close', () => {
          channels.delete(queue);
          consumerStarts.delete(queue);
        });
        await channel.prefetch(1);
        return channel;
      });
    channelPromise = pendingChannel.catch((error: unknown) => {
      channels.delete(queue);
      throw error;
    });
    channels.set(queue, channelPromise);
  }
  return channelPromise;
}

async function handleMessage(
  channel: Channel,
  queue: TassQueue,
  message: ConsumeMessage,
  handler: MessageHandler,
): Promise<void> {
  try {
    const data: unknown = JSON.parse(message.content.toString());
    await handler(data, {
      correlationId: message.properties.correlationId,
      redelivered: message.fields.redelivered,
      reply: (content, contentType) => {
        const replyTo = message.properties.replyTo;
        if (!replyTo || !message.properties.correlationId) {
          throw new Error('Message has no reply address');
        }
        channel.sendToQueue(replyTo, content, {
          correlationId: message.properties.correlationId,
          contentType,
        });
      },
    });
    channel.ack(message);
  } catch (error) {
    logError('rabbitmq.consumer.message_failed', error, {
      codigo: ErrorCatalog.T500.codigo,
      mensaje: ErrorCatalog.T500.descripcion,
      queue,
    });
    try {
      const retry = !message.fields.redelivered;
      channel.nack(message, false, retry);
      logInfo(retry ? 'rabbitmq.consumer.message_requeued' : 'rabbitmq.consumer.message_dead_lettered', {
        queue,
      });
    } catch (nackError) {
      logError('rabbitmq.consumer.retry_failed', nackError, {
        codigo: ErrorCatalog.T503.codigo,
        mensaje: ErrorCatalog.T503.descripcion,
        queue,
      });
    }
  }
}

export function startConsumer(queue: TassQueue, handler: MessageHandler): Promise<void> {
  let startPromise = consumerStarts.get(queue);
  if (!startPromise) {
    startPromise = getConsumerChannel(queue)
      .then(async (channel) => {
        await channel.consume(queue, (message) => {
          if (message === null) {
            logInfo('rabbitmq.consumer.cancelled', { queue });
            return;
          }
          void handleMessage(channel, queue, message, handler);
        });
        logInfo('rabbitmq.consumer.started', { queue });
      })
      .catch((error: unknown) => {
        consumerStarts.delete(queue);
        logError('rabbitmq.consumer.start_failed', error, {
          codigo: ErrorCatalog.T503.codigo,
          mensaje: ErrorCatalog.T503.descripcion,
          queue,
        });
        throw error;
      });
    consumerStarts.set(queue, startPromise);
  }
  return startPromise;
}

function isRecord(data: unknown): data is Record<string, unknown> {
  return typeof data === 'object' && data !== null;
}

async function handleVerificationEmail(data: unknown): Promise<void> {
  if (!isRecord(data) || data.type !== 'verification' || typeof data.userId !== 'string') {
    throw new TypeError('Invalid verification email message');
  }

  const user = await UserModel.findById(data.userId).select('correo estado').lean();
  if (!user || user.estado !== 'PENDIENTE') {
    logInfo('rabbitmq.email.message.skipped');
    return;
  }

  const token = generateVerificationToken(String(user._id));
  await sendVerificationEmail(user.correo, token);
  logInfo('rabbitmq.email.verification.sent');
}

async function handleConflictDetection(): Promise<void> {
  const conflicts = await detectLevelOneConflicts();
  logInfo('rabbitmq.conflict.detection.completed', { count: conflicts.length });
}

async function handleReportGeneration(data: unknown, context: MessageContext): Promise<void> {
  try {
    if (!isRecord(data) || (data.format !== 'pdf' && data.format !== 'excel')) {
      throw new TypeError('Invalid report generation message');
    }

    const buffer = data.format === 'pdf'
      ? await generateConflictPdf()
      : await generateConflictExcel();
    const contentType = data.format === 'pdf'
      ? 'application/pdf'
      : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

    context.reply(buffer, contentType);
    logInfo('rabbitmq.report.generated', { format: data.format });
  } catch (error) {
    logError('rabbitmq.report.generation.failed', error, {
      codigo: ErrorCatalog.T505.codigo,
      mensaje: ErrorCatalog.T505.descripcion,
    });

    if (context.redelivered && context.correlationId) {
      context.reply(
        Buffer.from(JSON.stringify({
          success: false,
          code: ErrorCatalog.T505.codigo,
          message: 'No fue posible generar el reporte.',
        })),
        'application/json',
      );
    }
    throw error;
  }
}

export async function startTassConsumers(): Promise<void> {
  await Promise.all([
    startConsumer(TASS_QUEUES.conflictDetection, handleConflictDetection),
    startConsumer(TASS_QUEUES.emailNotification, handleVerificationEmail),
    startConsumer(TASS_QUEUES.reportGeneration, handleReportGeneration),
  ]);
}
