import type { ConfirmChannel } from 'amqplib';
import { connectRabbitMQ } from '../config/rabbitmq.js';
import { ErrorCatalog } from '../utils/errorCatalog.js';
import { logError, logInfo } from '../utils/logger.js';

export const TASS_QUEUES = {
  conflictDetection: 'tass.conflict.detection',
  emailNotification: 'tass.email.notification',
  reportGeneration: 'tass.report.generation',
} as const;

export type TassQueue = (typeof TASS_QUEUES)[keyof typeof TASS_QUEUES];

let producerChannel: ConfirmChannel | undefined;
let channelPromise: Promise<ConfirmChannel> | undefined;

async function getProducerChannel(): Promise<ConfirmChannel> {
  if (producerChannel) {
    return producerChannel;
  }

  if (!channelPromise) {
    channelPromise = connectRabbitMQ()
      .then((connection) => connection.createConfirmChannel())
      .then((channel) => {
        channel.on('error', (error) => {
          logError('rabbitmq.producer.channel.failed', error, {
            codigo: ErrorCatalog.T503.codigo,
            mensaje: ErrorCatalog.T503.descripcion,
          });
        });
        channel.on('close', () => {
          if (producerChannel === channel) {
            producerChannel = undefined;
          }
        });
        producerChannel = channel;
        return channel;
      })
      .finally(() => {
        channelPromise = undefined;
      });
  }

  return channelPromise;
}

export async function publishToQueue(queue: TassQueue, data: unknown): Promise<void> {
  const serialized = JSON.stringify(data);
  if (serialized === undefined) {
    throw new TypeError('Message data must be JSON-serializable');
  }

  try {
    const channel = await getProducerChannel();
    channel.sendToQueue(queue, Buffer.from(serialized), {
      persistent: true,
      contentType: 'application/json',
    });
    await channel.waitForConfirms();
    logInfo('rabbitmq.message.published', { queue });
  } catch (error) {
    logError('rabbitmq.message.publish_failed', error, {
      codigo: ErrorCatalog.T503.codigo,
      mensaje: ErrorCatalog.T503.descripcion,
      queue,
    });
    throw error;
  }
}
