import { connect, type ChannelModel } from 'amqplib';
import { ErrorCatalog } from '../utils/errorCatalog.js';
import { logError, logInfo } from '../utils/logger.js';

let rabbitConnection: ChannelModel | undefined;
let connectionPromise: Promise<ChannelModel> | undefined;

export function connectRabbitMQ(): Promise<ChannelModel> {
  if (rabbitConnection) {
    return Promise.resolve(rabbitConnection);
  }

  if (!connectionPromise) {
    connectionPromise = openConnection().finally(() => {
      connectionPromise = undefined;
    });
  }

  return connectionPromise;
}

async function openConnection(): Promise<ChannelModel> {
  try {
    const url = process.env.RABBITMQ_URL;
    if (!url) {
      throw new Error('RABBITMQ_URL is required');
    }

    const connection = await connect(url);
    connection.on('error', (error) => {
      logError('rabbitmq.connection.failed', error, {
        codigo: ErrorCatalog.T503.codigo,
        mensaje: ErrorCatalog.T503.descripcion,
      });
    });
    connection.on('close', () => {
      if (rabbitConnection === connection) {
        rabbitConnection = undefined;
      }
    });

    rabbitConnection = connection;
    logInfo('rabbitmq.connected');
    return connection;
  } catch (error) {
    logError('rabbitmq.connection.failed', error, {
      codigo: ErrorCatalog.T503.codigo,
      mensaje: ErrorCatalog.T503.descripcion,
    });
    throw error;
  }
}

export async function closeRabbitMQ(): Promise<void> {
  const connection = rabbitConnection;
  rabbitConnection = undefined;

  if (connection) {
    await connection.close();
  }
}
