import { createClient } from 'redis';
import { ErrorCatalog } from '../utils/errorCatalog.js';
import { logError, logInfo } from '../utils/logger.js';

export const redisClient = createClient({
  url: process.env.REDIS_URL ?? 'redis://redis:6379',
  socket: {
    reconnectStrategy: (retries) => {
      if (retries > 20) {
        logError('redis.reconnect.giveup', new Error(`Falló después de ${retries} reintentos`));
        return new Error('Redis: máximo de reintentos excedido');
      }
      const delay = Math.min(retries * 100, 3000);
      logInfo('redis.reconnect.scheduled', { retries, delay });
      return delay;
    },
    connectTimeout: 10000,
  },
});

redisClient.on('connect', () => {
  logInfo('redis.connecting');
});

redisClient.on('ready', () => {
  logInfo('redis.ready');
});

redisClient.on('error', (error) => {
  logError('redis.connection.failed', error, {
    codigo: ErrorCatalog.T502.codigo,
    mensaje: ErrorCatalog.T502.descripcion,
  });
});

redisClient.on('reconnecting', () => {
  logInfo('redis.reconnecting');
});

export async function connectRedis(): Promise<void> {
  if (!redisClient.isOpen) {
    await redisClient.connect();
  }
}

export async function closeRedis(): Promise<void> {
  if (redisClient.isOpen) {
    await redisClient.close();
  }
}