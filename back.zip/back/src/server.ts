import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import { cliui } from "@poppinss/cliui";
import cron from "node-cron";

import { env } from "./config/env.js";
import index from "./routes/index.routes.js";
import { healthRouter } from "./routes/health.routes.js";
import { errorHandler } from "./middlewares/error.middleware.ts.js";
import { logError, logInfo } from "./utils/logger.js";
import { closeRabbitMQ, connectRabbitMQ } from "./config/rabbitmq.js";
import { closeRedis, connectRedis } from "./config/redis.js";
import { startTassConsumers } from "./services/messageConsumer.js";
import { publishToQueue, TASS_QUEUES } from "./services/messageProducer.js";
import { closeNotificationStreams } from "./services/notification-stream.service.js";

export const app = express();
let httpServer: ReturnType<typeof app.listen> | undefined;

const ui = cliui();
const sticker = ui.sticker();

// ─────────────────────────────────────────────
// Middlewares
// ─────────────────────────────────────────────

app.use(express.json());

app.use(
    cors({
        origin: "*",
        methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization"],
    }),
);

// ─────────────────────────────────────────────
// Routes
// ─────────────────────────────────────────────

app.use("/health", healthRouter);
app.use(index);

// ─────────────────────────────────────────────
// Error handler
// ─────────────────────────────────────────────

app.use(errorHandler);

// ─────────────────────────────────────────────
// Database
// ─────────────────────────────────────────────

const connectDB = async () => {
    try {
        await mongoose.connect(env.mongoUri);
        sticker
            .add("Base de datos Online")
            .render();
        logInfo("database.connected");
        return true;
    } catch (error) {
        sticker
            .add("Base de datos Offline")
            .render();
        logError("database.connection.failed", error);
        return false;
    }
};

// ─────────────────────────────────────────────
// Server
// ─────────────────────────────────────────────

const startServer = async () => {
  const databaseConnected = await connectDB();
  if (!databaseConnected) {
    logError("server.start.aborted", new Error("MongoDB unavailable"));
    process.exit(1);
  }

  try {
    await connectRedis();
  } catch (error) {
    logError("redis.connection.failed.at.startup", error, {
      codigo: 'T502',
      mensaje: 'Redis no disponible al iniciar, la caché está deshabilitada',
    });
    // No terminar el proceso, dejar que el cliente se reconecte en segundo plano
  }

  await connectRabbitMQ();
  await startTassConsumers();

// ─────────────────────────────────────────────
// Cron job
// ─────────────────────────────────────────────
    
    cron.schedule(
        "8 16 * * *",
        async () => {
            logInfo("cron.conflict_detection.started");

            try {
                await publishToQueue(TASS_QUEUES.conflictDetection, {
                    source: "scheduled",
                });
                logInfo("cron.conflict_detection.queued");
            } catch (error) {
                logError("cron.conflict_detection.failed", error);
            }
        },
        { timezone: "America/Bogota" },
    );

    httpServer = app.listen(
        env.port,
        "0.0.0.0",
        () => {
            sticker
                .add("Servidor HTTP iniciado")
                .add("")
                .add(
                    `Puerto: ${ui.colors.cyan(
                        env.port.toString()
                    )}`
                )
                .add(
                    `Entorno: ${ui.colors.red(
                        env.nodeEnv
                    )}`
                )
                .render();
            logInfo("server.http.started", {
                port: env.port,
                environment: env.nodeEnv,
            });
        }
    );
};

async function gracefulShutdown(signal: "SIGINT" | "SIGTERM"): Promise<void> {
    logInfo("server.shutdown.started", { signal });
    closeNotificationStreams();

    if (httpServer?.listening) {
        await new Promise<void>((resolve, reject) => {
            httpServer?.close((error) => {
                if (error) {
                    reject(error);
                } else {
                    resolve();
                }
            });
        }).catch((error: unknown) => {
            logError("server.http.shutdown.failed", error);
            process.exitCode = 1;
        });
    }

    const [rabbitResult, redisResult] = await Promise.allSettled([
        closeRabbitMQ(),
        closeRedis(),
    ]);

    if (rabbitResult.status === "rejected") {
        logError("rabbitmq.shutdown.failed", rabbitResult.reason);
        process.exitCode = 1;
    }
    if (redisResult.status === "rejected") {
        logError("redis.shutdown.failed", redisResult.reason);
        process.exitCode = 1;
    }

    logInfo("server.shutdown.completed", { signal });
    process.exit();
}

process.once("SIGINT", () => void gracefulShutdown("SIGINT"));
process.once("SIGTERM", () => void gracefulShutdown("SIGTERM"));

startServer();