import { Router } from 'express';
import { getAdministratorsController, getEmployeesController } from '../controllers/admin.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { authorizeRoles } from '../middlewares/role.middleware.js';

const router = Router();

router.get(
  '/administrators',
  authMiddleware,
  authorizeRoles('superAdmin'),
  getAdministratorsController,
);

router.get(
  '/employees',
  authMiddleware,
  authorizeRoles('admin', 'superAdmin'),
  getEmployeesController,
);

export default router;