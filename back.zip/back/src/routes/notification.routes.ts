import { Router } from 'express';
import {
  getNotificationList,
  getNotificationUnreadCount,
  markNotificationAsRead,
  notificationStream,
} from '../controllers/notification.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { authorizeRoles } from '../middlewares/role.middleware.js';

const router = Router();

router.use(authMiddleware);
router.get('/stream', authorizeRoles('superAdmin'), notificationStream);
router.get('/unread-count', getNotificationUnreadCount);
router.get('/', getNotificationList);
router.patch('/:id/read', markNotificationAsRead);

export default router;
