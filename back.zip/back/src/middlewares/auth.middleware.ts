import type { Request, Response, NextFunction } from 'express';
import { authBlacklistKey, authSessionKey, verifyToken } from '../services/jwt.service.js';
import { exists } from '../services/cacheService.js';
import { AuthenticationError, ValidationError } from '../utils/errors.js';
import type { JwtPayload } from '../utils/enums_types_interfaces.js';
import jwt from 'jsonwebtoken';

export function authMiddleware(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {

  return (async () => {
    try {

      const authorization = request.headers.authorization;

      if (!authorization) {
        throw new ValidationError(
          'Token de autenticación requerido.',
        );
      }

      const [type, token] = authorization.split(' ');

      if (type !== 'Bearer' || !token) {
        throw new ValidationError(
          'Formato de token inválido.',
        );
      }

      const payload = verifyToken(token) as JwtPayload;

      if (
        !payload.jti
        || !payload.exp
        || await exists(authBlacklistKey(payload.jti))
        || !(await exists(authSessionKey(payload.jti)))
      ) {
        throw new AuthenticationError('Token inválido o sesión cerrada.');
      }

      request.user = payload;
      next();

    } catch (error) {
      if (error instanceof jwt.TokenExpiredError) {
        response.status(401).json({
          success: false,
          code: 'TOKEN_EXPIRED',
          message: 'La sesión ha expirado.',
        });

        return;
      }

      next(error);
    }
  })();
}