import type { NextFunction, Request, Response } from 'express';
import { UserModel } from '../models/User.js';
import { CACHE_TTL, get as getCached, set as setCached } from '../services/cacheService.js';
import { ValidationError } from '../utils/errors.js';

function parsePageParameter(value: unknown, name: string, fallback: number, maximum?: number): number {
  if (value === undefined) {
    return fallback;
  }
  if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
    throw new ValidationError(`${name} debe ser un entero positivo.`);
  }

  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || (maximum !== undefined && parsed > maximum)) {
    throw new ValidationError(`${name} excede el valor permitido.`);
  }
  return parsed;
}

async function queryEmployees(page: number, limit: number) {
  const filter = { tipoVinculacion: 'empleado' as const };
  const [employees, total] = await Promise.all([
    UserModel.find(filter)
      .select('nombres apellidos correo tipoVinculacion cargo estado createdAt')
      .sort({ apellidos: 1, nombres: 1, _id: 1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean(),
    UserModel.countDocuments(filter),
  ]);

  return { employees, total };
}

export async function getAdministratorsController(
  _request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const administrators = await UserModel.find({ rolSistema: 'admin' })
      .select('nombres apellidos correo tipoVinculacion cargo estado createdAt')
      .sort({ apellidos: 1, nombres: 1 })
      .lean();

    response.status(200).json({
      success: true,
      data: administrators,
    });
  } catch (error) {
    next(error);
  }
}

export async function getEmployeesController(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const page = parsePageParameter(request.query.page, 'page', 1);
    const limit = parsePageParameter(request.query.limit, 'limit', 20, 100);
    const cacheKey = `employees:list:${page}:${limit}`;
    const cached = await getCached<Awaited<ReturnType<typeof queryEmployees>>>(cacheKey);
    const result = cached ?? await queryEmployees(page, limit);

    if (cached === null) {
      await setCached(cacheKey, result, CACHE_TTL.employees);
    }

    response.status(200).json({
      success: true,
      data: result.employees,
      pagination: {
        page,
        limit,
        total: result.total,
        totalPages: Math.ceil(result.total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
}