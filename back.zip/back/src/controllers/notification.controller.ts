import type { Request, Response, NextFunction } from 'express';
import { subscribeToNotifications } from '../services/notification-stream.service.js';
import {
  getNotifications,
  getUnreadNotificationCount,
  markNotificationRead,
} from '../services/notification.service.js';
import { ValidationError } from '../utils/errors.js';

function parsePageParameter(value: unknown, name: string, fallback: number, maximum?: number): number {
  if (value === undefined) {
    return fallback;
  }
  if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
    throw new ValidationError(`${name} debe ser un entero positivo.`);
  }

  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || (maximum !== undefined && parsed > maximum)) {
    throw new ValidationError(`${name} excede el valor permitido.`);
  }
  return parsed;
}

export async function getNotificationList(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const userId = request.user?.id;
    if (!userId) {
      throw new ValidationError('No fue posible identificar al usuario autenticado.');
    }

    const page = parsePageParameter(request.query.page, 'page', 1);
    const limit = parsePageParameter(request.query.limit, 'limit', 20, 100);
    const result = await getNotifications(userId, page, limit);
    response.status(200).json({
      success: true,
      data: result.notifications,
      pagination: {
        page,
        limit,
        total: result.total,
        totalPages: Math.ceil(result.total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getNotificationUnreadCount(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const userId = request.user?.id;
    if (!userId) {
      throw new ValidationError('No fue posible identificar al usuario autenticado.');
    }

    const count = await getUnreadNotificationCount(userId);
    response.status(200).json({ success: true, data: { unreadCount: count } });
  } catch (error) {
    next(error);
  }
}

export async function markNotificationAsRead(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const userId = request.user?.id;
    if (!userId) {
      throw new ValidationError('No fue posible identificar al usuario autenticado.');
    }

    const notificationId = request.params.id;
    if (typeof notificationId !== 'string') {
      throw new ValidationError('ID de notificación inválido.');
    }
    const notification = await markNotificationRead(userId, notificationId);
    response.status(200).json({ success: true, data: notification });
  } catch (error) {
    next(error);
  }
}

export function notificationStream(
  request: Request,
  response: Response,
  next: NextFunction,
): void {
  const userId = request.user?.id;
  if (!userId) {
    next(new ValidationError('No fue posible identificar al usuario autenticado.'));
    return;
  }
  subscribeToNotifications(userId, response);
}
