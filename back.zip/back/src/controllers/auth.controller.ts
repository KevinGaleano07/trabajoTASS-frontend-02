import type { Request, Response, NextFunction } from 'express';
import { createHash } from 'node:crypto';
import bcrypt from 'bcrypt';
import { UserModel } from '../models/User.js';
import { validateRegistration } from '../validators/registration.validator.js';
import {
  AppError,
  ValidationError,
  ConflictError,
  DatabaseError,
} from '../utils/errors.js';
import { CompanyModel } from '../models/company.js';
import { generateAuthToken, verifyToken} from '../services/jwt.service.js';
import { enqueueVerificationEmail } from '../services/email.service.js';
import { env } from '../config/env.js';
import { AuthorizedPersonModel } from '../models/AuthorizedPerson.js';
import { logError } from '../utils/logger.js';
import { CACHE_TTL, del, get, incrementWithTtl, set } from '../services/cacheService.js';
import { authBlacklistKey, authSessionKey } from '../services/jwt.service.js';
import { ErrorCatalog } from '../utils/errorCatalog.js';

function positiveIntegerSetting(name: string, fallback: number): number {
  const value = Number(process.env[name] ?? fallback);
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return value;
}

const loginMaxFailedAttempts = positiveIntegerSetting('LOGIN_MAX_FAILED_ATTEMPTS', 5);
const loginAttemptWindowSeconds = positiveIntegerSetting('LOGIN_ATTEMPT_WINDOW_SECONDS', 900);

function loginAttemptKey(normalizedEmail: string): string {
  const accountHash = createHash('sha256').update(normalizedEmail).digest('hex');
  return `auth:login-attempts:${accountHash}`;
}

export async function register(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const {
      nombres,
      apellidos,
      tipoDocumento,
      numeroDocumento,
      correo,
      telefono,
      tipoVinculacion,
      empresaProveedora,
      cargo,
      password,
      confirmPassword,
    } = request.body;

    const validation = validateRegistration({
      nombres,
      apellidos,
      tipoDocumento,
      numeroDocumento,
      correo,
      telefono,
      tipoVinculacion,
      empresaProveedora,
      cargo,
      password,
      confirmPassword,
    });

    if (!validation.valid) {
      throw new ValidationError('Los datos proporcionados no son válidos.', validation.errors);
    }

    const normalizedEmail = String(correo).toLowerCase().trim();
    const normalizedDocument = String(numeroDocumento).trim();

    const emailExists = await UserModel.exists({ correo: normalizedEmail });
    if (emailExists) {
      throw new ConflictError('Ya existe una cuenta registrada con este correo electrónico.', 'User');
    }

    const documentExists = await UserModel.exists({
      tipoDocumento,
      numeroDocumento: normalizedDocument,
    });

    if (documentExists) {
      throw new ConflictError('Ya existe una cuenta registrada con este tipo y número de documento.', 'User');
    }

    // Si es proveedor, verificar que la empresa exista
    if (tipoVinculacion === 'proveedor') {

      const company = await CompanyModel.exists({
        _id: empresaProveedora,
      });

      if (!company) {
        throw new ValidationError(
          'La empresa seleccionada no existe.',
          {
            empresaProveedora: 'Empresa inválida.',
          }
        );
      }

    }

      const authorizedPerson = await AuthorizedPersonModel.findOne({
        tipoDocumento,
        numeroDocumento: normalizedDocument,
        estado: 'ACTIVO',
      });

      if (!authorizedPerson) {

        throw new ValidationError(
          'Los datos de autorización no son válidos.',
          {
            numeroDocumento: 'Los datos de autorización no son válidos.',
          }
        );
        
      }

    const cargoAutorizado = String(authorizedPerson.cargo).trim().toLowerCase();
    const cargoRegistrado = String(cargo).trim().toLowerCase();

    if (cargoAutorizado !== cargoRegistrado) {
      throw new ValidationError(
        'Los datos de autorización no son válidos.',
        {
          numeroDocumento: 'Los datos de autorización no son válidos.',
          cargo: 'Los datos de autorización no son válidos.',
        }
      );
    }

    const passwordHash = await bcrypt.hash(String(password), 10);

    const user = await UserModel.create({
      nombres: String(nombres).trim(),
      apellidos: String(apellidos).trim(),
      tipoDocumento,
      numeroDocumento: normalizedDocument,
      correo: normalizedEmail,
      telefono: String(telefono).trim(),
      tipoVinculacion,
      empresaProveedora: tipoVinculacion === 'proveedor'? empresaProveedora: null,
      cargo: String(cargo).trim(),
      passwordHash,
      rolSistema: 'usuario',
      estado: 'PENDIENTE',
    }).catch((error) => {
      logError('auth.registration.database_failure', error);
      throw new DatabaseError(
        'No fue posible crear el usuario.',
        error
      );
    });

    await enqueueVerificationEmail(user._id.toString());
    

    response.status(201).json({
      success: true,
      message: 'Usuario creado correctamente. La cuenta está pendiente de activación.',
      data: {
        user: {
          id: user._id,
          nombres: user.nombres,
          apellidos: user.apellidos,
          correo: user.correo,
          estado: user.estado,
          tipoVinculacion: user.tipoVinculacion,
        },
      },
    });
  } catch (error: unknown) {
    next(error);
  }
}

export async function verifyEmail(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {

  try {

    const token = String(request.query.token);

    const payload = verifyToken(token) as {
      id: string;
      type: string;
    };

    if (payload.type !== 'verify-email') {
      response.status(400).send('Token inválido');
      return;
    }

    await UserModel.findByIdAndUpdate(
      payload.id,
      { estado: 'ACTIVO' }
    );

    return response.redirect(`${env.frontendUrl}/login?verified=true`);

  } catch (error) {
    next(error);
  }


}

export async function login(request: Request, response: Response, next: NextFunction): Promise<void> {
  try {
    const { correo, password } = request.body;
    const normalizedEmail = String(correo).toLowerCase().trim();
    const failedAttemptsKey = loginAttemptKey(normalizedEmail);
    const failedAttempts = await get<number>(failedAttemptsKey);

    if (failedAttempts !== null && failedAttempts >= loginMaxFailedAttempts) {
      throw new AppError(
        'Demasiados intentos fallidos. Intenta de nuevo más tarde.',
        ErrorCatalog.T429.httpStatus,
        ErrorCatalog.T429.codigo,
      );
    }

    const user = await UserModel.findOne({
      correo: normalizedEmail,
    }).select('+passwordHash');

    if (!user) {
      await incrementWithTtl(failedAttemptsKey, loginAttemptWindowSeconds);
      throw new ConflictError(
        'Correo o contraseña incorrectos.',
        'User',
      );
    }

    const passwordCorrecta = await bcrypt.compare(
      String(password),
      user.passwordHash,
    );

    if (!passwordCorrecta) {
      await incrementWithTtl(failedAttemptsKey, loginAttemptWindowSeconds);
      throw new ConflictError(
        'Correo o contraseña incorrectos.',
        'User',
      );
    }

    if (user.estado !== 'ACTIVO') {
      throw new ValidationError(
        'Debes activar tu cuenta para iniciar sesión',
        undefined,
        'ACCOUNT_NOT_ACTIVE'
      );
    }

    const token = generateAuthToken(user);
    const sessionTtl = Math.min(
      CACHE_TTL.session,
      token.expiresAt - Math.floor(Date.now() / 1000),
    );
    await Promise.all([
      del(failedAttemptsKey),
      set(authSessionKey(token.jti), true, sessionTtl),
    ]);

    response.status(200).json({
      success: true,
      message: 'Login exitoso',
      data: {
        token: token.token,
        user: {
          id: user._id,
          nombres: user.nombres,
          apellidos: user.apellidos,
          correo: user.correo,
          tipoDocumento: user.tipoDocumento,
          numeroDocumento: user.numeroDocumento,
          telefono: user.telefono,
          tipoVinculacion: user.tipoVinculacion,
          rolSistema: user.rolSistema,
          cargo: user.cargo,
          estado: user.estado,
        },
      },
    });

  } catch (error) {
    next(error);
  }

}

export async function logout(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const { jti, exp } = request.user ?? {};
    if (!jti || !exp) {
      throw new ValidationError('No fue posible identificar la sesión.');
    }

    const remainingTtl = exp - Math.floor(Date.now() / 1000);
    if (remainingTtl > 0) {
      await set(authBlacklistKey(jti), true, remainingTtl);
    }
    await del(authSessionKey(jti));

    response.status(200).json({
      success: true,
      message: 'Sesión cerrada correctamente.',
    });
  } catch (error) {
    next(error);
  }
}

export async function updateProfile(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const userId = request.user?.id;
    if (!userId) {
      throw new ValidationError('No fue posible identificar al usuario autenticado.');
    }

    const { nombres, correo, telefono } = request.body ?? {};
    const fieldErrors: Record<string, string> = {};
    const updates: { nombres?: string; correo?: string; telefono?: string } = {};

    if (nombres !== undefined) {
      if (typeof nombres !== 'string' || nombres.trim().length < 2) {
        fieldErrors.nombres = 'Ingresa al menos 2 caracteres.';
      } else {
        updates.nombres = nombres.trim();
      }
    }

    if (correo !== undefined) {
      if (typeof correo !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.trim())) {
        fieldErrors.correo = 'Ingresa un correo electrónico válido.';
      } else {
        updates.correo = correo.trim().toLowerCase();
      }
    }

    if (telefono !== undefined) {
      if (typeof telefono !== 'string' || !/^\d{10,}$/.test(telefono.trim())) {
        fieldErrors.telefono = 'El teléfono debe tener al menos 10 dígitos.';
      } else {
        updates.telefono = telefono.trim();
      }
    }

    if (Object.keys(fieldErrors).length > 0) {
      throw new ValidationError('Revisa los datos del perfil.', fieldErrors);
    }

    if (Object.keys(updates).length === 0) {
      throw new ValidationError('Debes enviar al menos un dato para actualizar.');
    }

    if (updates.correo) {
      const existingUser = await UserModel.exists({
        correo: updates.correo,
        _id: { $ne: userId },
      });
      if (existingUser) {
        throw new ConflictError('Ese correo ya está asociado a otra cuenta.', 'User');
      }
    }

    const user = await UserModel.findById(userId);
    if (!user) {
      throw new ValidationError('El usuario no existe.');
    }

    Object.assign(user, updates);
    await user.save();

    const refreshedToken = generateAuthToken(user);
    const remainingTtl = Math.min(
      CACHE_TTL.session,
      refreshedToken.expiresAt - Math.floor(Date.now() / 1000),
    );
    await set(authSessionKey(refreshedToken.jti), true, remainingTtl);

    const oldJti = request.user?.jti;
    if (oldJti) {
      await del(authSessionKey(oldJti));
    }

    response.status(200).json({
      success: true,
      message: 'Perfil actualizado correctamente.',
      data: {
        token: refreshedToken.token,
        user: {
          id: user._id,
          nombres: user.nombres,
          apellidos: user.apellidos,
          correo: user.correo,
          tipoDocumento: user.tipoDocumento,
          numeroDocumento: user.numeroDocumento,
          telefono: user.telefono,
          tipoVinculacion: user.tipoVinculacion,
          rolSistema: user.rolSistema,
          cargo: user.cargo,
          estado: user.estado,
        },
      },
    });
  } catch (error) {
    if (
      typeof error === 'object'
      && error !== null
      && 'code' in error
      && error.code === 11000
    ) {
      next(new ConflictError('Ese correo ya está asociado a otra cuenta.', 'User'));
      return;
    }
    next(error);
  }
}

 export async function changePassword(request: Request, response: Response, next: NextFunction): Promise<void> {

    try {

      const {
        currentPassword,
        newPassword,
      } = request.body;

      if (!currentPassword || !newPassword) {

        throw new ValidationError('La contraseña actual y la nueva contraseña son obligatorias.');
      }

      const userId = request.user?.id;

      if (!userId) {
        throw new ValidationError('No fue posible identificar al usuario autenticado.');
      }

      const user = await UserModel.findById(userId).select('+passwordHash');

      if (!user) {
        throw new ValidationError('El usuario no existe.');
      }

      const currentPasswordCorrect = await bcrypt.compare(String(currentPassword), user.passwordHash);

      if (!currentPasswordCorrect) {
        throw new ValidationError('La contraseña actual es incorrecta.',
        {
          currentPassword: 'La contraseña actual es incorrecta.'
        },
        'INVALID_CURRENT_PASSWORD',
      );
      }

      const passwordHash = await bcrypt.hash(String(newPassword), 10,);

      user.passwordHash = passwordHash;

      await user.save();

      response.status(200).json({
        success: true,
        message: 'Contraseña actualizada correctamente.'
      });

    } catch (error) {

      next(error);

    }

  }
